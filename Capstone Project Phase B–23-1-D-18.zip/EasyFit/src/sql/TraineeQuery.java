package sql;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import Entities.Exercise;
import Entities.Feedback;
import Entities.Request;
import Entities.Session;
import Entities.Target;
import Entities.WeeklyReport;


public class TraineeQuery {
	
	public static Map<String, Session> getProgram(int traineeID) {	 
		Map<String, Session> sessions = null;
	    if (DBConnect.conn != null) {
	    	sessions = new TreeMap<String, Session>();
	        String sql = "SELECT * FROM session WHERE trainee_ID = ?";
	        try {
	            PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
	            stmt.setInt(1, traineeID);
	            ResultSet resultSet = stmt.executeQuery();

	            while (resultSet.next()) {
	            	 int traineeId = resultSet.getInt("trainee_ID");
		             byte[] exercisesBytes = resultSet.getBytes("exercises");
		             byte[] setsBytes = resultSet.getBytes("sets");
		             byte[] repetitionsBytes = resultSet.getBytes("repetitions");
		             String sessionTag = resultSet.getString("tag");

		             ArrayList<Exercise> exercises = deserializeArrayList(exercisesBytes);
		             ArrayList<String> sets = deserializeArrayList(setsBytes);
		             ArrayList<String> repetitions = deserializeArrayList(repetitionsBytes);
		             
		             sessions.put(sessionTag, new Session(traineeId, exercises, sets, repetitions, sessionTag));
						/*
						 * System.out.println("Trainee ID: " + traineeId);
						 * System.out.println("Exercises: " + exercises); System.out.println("Sets: " +
						 * sets); System.out.println("Repetitions: " + repetitions);
						 * System.out.println("Session Tag: " + sessionTag);
						 * System.out.println("--------------------");
						 */
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    } else {
	        System.out.println("DB connection is null");
	    }
	    return sessions;
	}
	
	public static <T> ArrayList<T> deserializeArrayList(byte[] bytes) {
        ArrayList<T> arrayList = new ArrayList<>();
        try (ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
             ObjectInputStream ois = new ObjectInputStream(bis)) {

            arrayList = (ArrayList<T>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return arrayList;
    }

	public static String getName(int traineeID) {
		System.out.println("in sql getName, start:");
		String name = "";
		if (DBConnect.conn != null) {
	        String sql = "SELECT first_name, last_name FROM user WHERE user_ID = ?";
	        try {
	            PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
	            stmt.setInt(1, traineeID);
	            ResultSet resultSet = stmt.executeQuery();

	            while (resultSet.next()) {
	            	 String first = resultSet.getString("first_name");
	            	 String last = resultSet.getString("last_name");
	            	 name = first + " " + last;
	            	 System.out.println("in sql getName, name: "  + name);
	            }
	            System.out.println("in sql getName, after: "  + name);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    } else {
	        System.out.println("DB connection is null");
	    }
	    return name;
	}

	public static void addWeeklyReport(WeeklyReport wr) {
		PreparedStatement stmt;
		String sql = "INSERT INTO weekly_report (trainee_ID, sessions_performed, weight, "
				+ "photo, notes, year, month, week, exercises_notes, status, trainer_ID) VALUES (?, ?, ?, ?, ?,"
				+ " ?, ?, ?, ?, ?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, wr.getTraineeID());
				stmt.setInt(2, wr.getSessionsPerformed());
				stmt.setInt(3, wr.getWeight());
				stmt.setBytes(4, wr.getPhoto());
				stmt.setString(5, wr.getNotes());
				stmt.setInt(6, wr.getYear());
				stmt.setInt(7, wr.getMonth());
				stmt.setInt(8, wr.getWeek());
				stmt.setBytes(9, serializeMap(wr.getExerciseNotes()));
				stmt.setString(10, wr.getStatus());
				stmt.setInt(11, wr.getTrainerID());
				stmt.executeUpdate();

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
	}
	
	private static byte[] serializeMap(Map<String, String> exerciseNotes) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(exerciseNotes);
            oos.close();
            return baos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

	public static ArrayList<Feedback> getTraineeFeedbacks(int traineeID) {
		ArrayList<Feedback> arr = new ArrayList<Feedback>();
		if (DBConnect.conn != null) {
			String sql = "SELECT * FROM feedback WHERE trainee_ID = ?";
	        try {
	            PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
	            stmt.setInt(1, traineeID);
	            ResultSet resultSet = stmt.executeQuery();

	            if (resultSet.next()) {
	            	int feedbackID = resultSet.getInt("feedback_ID");
	            	String notes = resultSet.getString("notes");
	            	String exercisesNotes = resultSet.getString("exercises_notes");
	            	int year = resultSet.getInt("year");
	            	int month = resultSet.getInt("month");
	            	int week = resultSet.getInt("week");
	            	Feedback f = new Feedback(traineeID, exercisesNotes, notes, year, month, week);
	            	f.setFeedbackID(feedbackID);
	            	arr.add(f);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    } else {
	        System.out.println("DB connection is null");
	    }
		
		 // Sort in descending order based on feedbackID
		Collections.sort(arr, new Comparator<Feedback>() {
            @Override
            public int compare(Feedback f1, Feedback f2) {
                return Integer.compare(f2.getFeedbackID(), f1.getFeedbackID());
            }
        });
		
	    return arr;  
	}

	public static String addRequest(Request r) {
		PreparedStatement stmt;
		String sql = "INSERT INTO request (trainee_ID, type, details, "
				+ "goal, sessions_per_week, session_duration, activity_level, status) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, r.getTraineeID());
				stmt.setString(2, r.getType());
				stmt.setString(3, r.getDetails());
				stmt.setString(4, r.getGoal());
				stmt.setInt(5, r.getSessionsPerWeek());
				stmt.setInt(6, r.getSessionDuration());
				stmt.setInt(7, r.getActivityLevel());
				stmt.setString(8, "open");
				stmt.executeUpdate();

			}catch (SQLException e) { // catch for manager
				return "Error Sending Request";
			}
		}else
			return "DB Connection is down";
		return "OK";
	}

	public static int getTrainerID(int traineeID) {
		int trainerID = -1;
		if (DBConnect.conn != null) {
			String sql = "SELECT * FROM trainer_trainee WHERE trainee_ID = ?";
	        try {
	            PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
	            stmt.setInt(1, traineeID);
	            ResultSet resultSet = stmt.executeQuery();

	            if (resultSet.next()) {
	            	trainerID = resultSet.getInt("trainer_ID");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    } else {
	        System.out.println("DB connection is null");
	    }	
	    return trainerID;  
	}
}
