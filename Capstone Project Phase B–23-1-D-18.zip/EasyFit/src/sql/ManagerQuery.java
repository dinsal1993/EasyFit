package sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Year;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import Entities.Request;
import Entities.Trainer;

public class ManagerQuery {

	public static ArrayList<Request> getAllRequest() {
		ArrayList<Request> arr = new ArrayList<>();
		String sql = "SELECT * FROM request WHERE status = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setString(1, "open");
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	            	int requestID = resultSet.getInt("request_ID");
	                int traineeID = resultSet.getInt("trainee_ID");
	                String type = resultSet.getString("type");
	                String detail = resultSet.getString("details");
	                String goal = resultSet.getString("goal");
	                int perWeek = resultSet.getInt("sessions_per_week");
	                int duration = resultSet.getInt("session_duration");
	                int activity = resultSet.getInt("activity_level");
	                String status = resultSet.getString("status");
	                
	                Request r = new Request(requestID, traineeID, type, detail, goal, perWeek, duration, activity, status);
	                arr.add(r);
	            }
			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		// Get the trainees requests
		return arr;
	}

	public static Request getRequest(int requestID) {
		System.out.println("in getRequest sql");
		String sql = "SELECT * FROM request WHERE request_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, requestID);
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	                int traineeID = resultSet.getInt("trainee_ID");
	                String type = resultSet.getString("type");
	                String detail = resultSet.getString("details");
	                String goal = resultSet.getString("goal");
	                int perWeek = resultSet.getInt("sessions_per_week");
	                int duration = resultSet.getInt("session_duration");
	                int activity = resultSet.getInt("activity_level");
	                String status = resultSet.getString("status");
	                
	                Request r = new Request(requestID, traineeID, type, detail, goal, perWeek, duration, activity, status);
	                System.out.println("Request in sql is: " + r);
	                return r;
	            }
			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		// Get the trainees requests
		return null;
	}

	public static ArrayList<Trainer> getTrainersByTarget(String goal) {
		ArrayList<Trainer> arr = new ArrayList<>();
		String sql = "SELECT * FROM user WHERE role = ? AND specialty = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setString(1, "trainer");
				stmt.setString(2, goal);
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	            	int trainerID = resultSet.getInt("user_ID");
	                String firstName = resultSet.getString("first_name");
	                String lastName = resultSet.getString("last_name");
	                Trainer t = new Trainer(trainerID, "", "", firstName, lastName, "", null, false, "");
	                arr.add(t);
	            }
			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		// Get the trainees requests
		return arr;
	}

	public static ArrayList<Trainer> getTrainersByTrainer(int trainerID) {
		ArrayList<Trainer> arr = new ArrayList<>();
		String specialty = getSpecialty(trainerID);
		System.out.println("Specialty: " + specialty);
		String sql = "SELECT * FROM user WHERE role = ? AND specialty = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setString(1, "trainer");
				stmt.setString(2, specialty);
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	            	int id = resultSet.getInt("user_ID");
	            	if(id != trainerID) {
	            		String firstName = resultSet.getString("first_name");
	            		String lastName = resultSet.getString("last_name");
	            		Trainer t = new Trainer(id, "", "", firstName, lastName, "", null, false, "");
	                arr.add(t);
	            	}
	            }
			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		// Get the trainees requests
		return arr;
	}

	private static String getSpecialty(int trainerID) {
		String specialty = "";
		String sql = "SELECT specialty FROM user WHERE user_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, trainerID);
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	            	return resultSet.getString("specialty");
	            }
			}catch (SQLException e) { 
				e.printStackTrace();
			}
		}

		return specialty;
		
	}

	public static String confirmRequestTarget(Request r, int trainerID) {
		updateTrainer(r, trainerID);
		updateTarget(r);
		updateRequest(r);
		return "Success";
	}

	private static void updateRequest(Request r) {
		String sql = "UPDATE request SET status = ? WHERE request_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setString(1, "closed");
				stmt.setInt(2, r.getRequestID());

				stmt.executeUpdate();
			}catch (SQLException e) { 
				e.printStackTrace();
			}
		}
		
	}

	private static void updateTarget(Request r) {
		String sql = "UPDATE target SET goal = ?, sessions_per_week = ?, session_duration = ?, activity_level = ?"
				+ " WHERE user_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setString(1, r.getGoal());
				stmt.setInt(2, r.getSessionsPerWeek());
				stmt.setInt(3, r.getSessionDuration());
				stmt.setInt(4, r.getActivityLevel());
				stmt.setInt(5, r.getTraineeID());
				
				stmt.executeUpdate();
			}catch (SQLException e) { 
				e.printStackTrace();
			}
		}
		
	}

	private static void updateTrainer(Request r, int trainerID) {
		String sql = "UPDATE trainer_trainee SET trainer_ID = ? WHERE trainee_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, trainerID);
				stmt.setInt(2, r.getTraineeID());
				
				stmt.executeUpdate();
			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
	}

	public static String confirmRequestTrainer(Request r, int trainerID) {
		updateTrainer(r, trainerID);
		updateRequest(r);
		return "Success";
	}

	public static String rejectRequest(Request r) {
		updateRequest(r);
		return "Success";
	}

	public static String confirmRequestSignup(Request r, int traineeID, int trainerID) {
		System.out.println("in sql confirmSignup: req: " + r+ ":::: traineeID: " + traineeID + ":::::: trainerID: " + trainerID);
		updateRequest(r);
		insertTrainer(traineeID, trainerID);
		updateApproved(traineeID);
		return "Success";
	}

	private static void updateApproved(int traineeID) {
		String sql = "UPDATE user SET approved = ? WHERE user_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setBoolean(1, true);
				stmt.setInt(2, traineeID);
				
				stmt.executeUpdate();
			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		
	}

	private static void insertTrainer(int traineeID, int trainerID) {
		PreparedStatement stmt;
		String sql = "INSERT INTO trainer_trainee (trainer_ID, trainee_ID)"
				+ " VALUES (?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, trainerID);
				stmt.setInt(2, traineeID);
				
				stmt.executeUpdate();

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		
	}


	public static Map<String, Integer> getSpecialtyList() {
		Map<String, Integer> arr = new HashMap<>();
		String sql = "SELECT specialty_ID, name FROM specialty";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	            	int id = resultSet.getInt("specialty_ID");
	            	String name = resultSet.getString("name");
	            	arr.put(name, id);
	            }
			}catch (SQLException e) { 
				e.printStackTrace();
			}
		}

		return arr;
	}

	public static Map<String, Integer> getTrainers() {
		Map<String, Integer> arr = new HashMap<>();
		String sql = "SELECT user_ID, first_name, last_name FROM user WHERE role = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setString(1, "trainer");
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	            	int id = resultSet.getInt("user_ID");
	            	String name = resultSet.getString("first_name") + " " + resultSet.getString("last_name");
	            	arr.put(name, id);
	            }
			}catch (SQLException e) { 
				e.printStackTrace();
			}
		}

		return arr;
	}

	public static String removeTraineeFromTrainer(int id) {
		String sql = "DELETE FROM trainer_trainee WHERE trainee_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, id);
				int rowsAffected = stmt.executeUpdate();
	            if(rowsAffected>0)
	            	return "Success";
			}catch (SQLException e) { 
				e.printStackTrace();
			}
		}

		return "error";
	}

	public static String addTraineeToTrainer(int trainerID, int traineeID) {
		PreparedStatement stmt;
		String sql = "INSERT INTO trainer_trainee (trainer_ID, trainee_ID) "
				+ "VALUES (?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, trainerID);
				stmt.setInt(2, traineeID);
				int rowsAffected = stmt.executeUpdate();
				if(rowsAffected>0)
	            	return "Success";
			}catch (SQLException e) { // catch for manager
				System.out.println("Error Sending Request");
			}
		}else
			System.out.println("DB Connection is down");
		return "error";
	}

	public static String deleteUser(int id) {
		String r1 = deleteTrainee(id);
		String r2 = removeTraineeFromTrainer(id);
		if(r1.equals("error") || r2.equals("error"))
			return "error";
		return "Success";
		
	}

	private static String deleteTrainee(int id) {
		String sql = "DELETE FROM user WHERE user_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, id);
				int rowsAffected = stmt.executeUpdate();
	            if(rowsAffected>0)
	            	return "Success";
			}catch (SQLException e) { 
				e.printStackTrace();
			}
		}

		return "error";
		
	}

}
