package sql;

import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Year;
import java.util.ArrayList;

import Entities.Manager;
import Entities.Person;
import Entities.Specialty;
import Entities.Target;
import Entities.Trainee;
import Entities.Trainer;
import sql.DBConnect;

public class UserQuery {
	//This class is used for general user queries like login, logout, signup, getting user info.

	public static String login(String emailParamater, String hashedPassword) throws NoSuchAlgorithmException {
		PreparedStatement stmt;
		ResultSet rs;
		int rowCounter = 0;
		String userID = null, online = null, role = null, email = null, password = null;
		
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(
						"SELECT user_ID, online, role, password FROM easyfit.user WHERE email=?");
				stmt.setString(1, emailParamater);
				rs = stmt.executeQuery();

				while (rs.next()) {
					rowCounter++;

					userID = rs.getString("user_ID");
					online = String.valueOf(rs.getBoolean("online"));
					role = rs.getString("role");
					password = rs.getString("password");
				}
			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}else
			return "Database connection error";
		System.out.println("rowCount is: " + rowCounter);
		System.out.println("in UserQuery. database pass is: " + password + ", pass from user(hashed) is: " + hashedPassword);
		System.out.println("is same? " + EncryptionUtils.isPasswordValid(password, hashedPassword));
		if(rowCounter == 0)
			return "Invalid email";
		if(online == "true")
			return "UserAlreadyConnected";
		if(!EncryptionUtils.isPasswordValid(password, hashedPassword))
			return "Invalid password";
		
		updateOnline(userID, true);
		return userID + "!" + role;
	}

	public static void updateOnline(String userID, boolean newState) {
		// update the user 'online' state on login and logout

		int result;
		Statement stmt;
		ResultSet rs;
		if (DBConnect.conn != null) {
			try {
				String newStateString = String.valueOf(newState);
				stmt = DBConnect.conn.createStatement();
				String query = "UPDATE easyfit.user" + " SET online = " + newStateString 
				+ " WHERE user_ID = " + Integer.parseInt(userID) + ";";
				
				stmt.executeUpdate(query);

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
	}

	public static String createTrainee(Trainee t, Target tg) {
		if(isUserExist(t.getEmail(), t.getUserID()))
			return "Email / ID already in use";
		createBasicTrainee(t);
		createTarget(tg);
		createRequest(t,tg);
		return "Success";
	}

	private static void createRequest(Trainee t, Target tg) {
		PreparedStatement stmt;
		String sql = "INSERT INTO request (trainee_ID, type, details, goal, sessions_per_week, session_duration, "
				+ "activity_level, status) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, t.getUserID());
				stmt.setString(2, "Signup");
				stmt.setString(3, "");
				stmt.setString(4, tg.getGoal());
				stmt.setInt(5, 0);
				stmt.setInt(6, 0);
				stmt.setInt(7, 0);
				stmt.setString(8, "open");
				stmt.executeUpdate();

			}catch (SQLException e) { // catch for manager
				System.out.println("Error Sending Request");
			}
		}else
			System.out.println("DB Connection is down");		
	}

	private static boolean isUserExist(String email, int id) {
		String query = "SELECT COUNT(*) FROM user WHERE email = ? OR user_ID = ?";
		boolean userExist = false;
		try (
	             PreparedStatement statement = DBConnect.conn.prepareStatement(query)) {

	            statement.setString(1, email);
	            statement.setInt(2, id);
	            ResultSet resultSet = statement.executeQuery();

	            if (resultSet.next()) {
	                int count = resultSet.getInt(1);
	                userExist = count > 0;
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Handle the exception appropriately
	        }
        return userExist;
	}

	private static void createTarget(Target tg) {
		PreparedStatement stmt;
		String sql = "INSERT INTO target (user_ID, goal, sessions_per_week, "
				+ "session_duration, activity_level) VALUES (?, ?, ?, ?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, tg.getUserID());
				stmt.setString(2, tg.getGoal());
				stmt.setInt(3, tg.getSessionsPerWeek());
				stmt.setInt(4, tg.getSessionDuration());
				stmt.setInt(5, tg.getActivityLevel());
				
				stmt.executeUpdate();

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		
	}

	private static void createBasicTrainee(Trainee t) {
		PreparedStatement stmt;
		String sql = "INSERT INTO user (user_ID, email, password, first_name, last_name, phone, "
				+ "address, weight, height, birth_year, birth_month, age, medical, approved, "
				+ "online, role, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, t.getUserID());
				stmt.setString(2, t.getEmail());
				stmt.setString(3, t.getPassword());
				stmt.setString(4, t.getFirstName());
				stmt.setString(5, t.getLastName());
				stmt.setString(6, t.getPhone());
				stmt.setString(7, t.getAddress());
				stmt.setInt(8, t.getWeight());
				stmt.setInt(9, t.getHeight());
				stmt.setInt(10, t.getBirthYear());
				stmt.setInt(11, t.getBirthMonth());
				stmt.setInt(12, Year.now().getValue() - t.getBirthYear());
				stmt.setString(13, t.getMedical());
				stmt.setBoolean(14, false);
				stmt.setBoolean(15, false);
				stmt.setString(16, "trainee");
				stmt.setString(17, t.getGender());
				
				stmt.executeUpdate();

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		
	}

	public static String getDecryptionKey(String userID) {
		System.out.println("in getDecryptionKey sql");
		PreparedStatement stmt;
		ResultSet rs;

		String firstName = "", lastName = "", key = "";
		
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(
						"SELECT first_name, last_name FROM easyfit.user WHERE user_ID=?");
				stmt.setString(1, userID);
				rs = stmt.executeQuery();

				while (rs.next()) {
					firstName = rs.getString("first_name");
					lastName = rs.getString("last_name");
				}
			}catch (SQLException e) { 
				e.printStackTrace();
			}
		}
		return EncryptionUtils.createPrimeKey(firstName, lastName, userID);
	}

	public static String addTrainer(Trainer t) {
		if(isUserExist(t.getEmail(), t.getUserID()))
			return "Email / ID already in use";
		
		PreparedStatement stmt;
		String sql = "INSERT INTO user (user_ID, email, password, first_name, last_name, phone, specialty, "
				+ "approved, online, role, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, t.getTrainerID());
				stmt.setString(2, t.getEmail());
				stmt.setString(3, t.getPassword());
				stmt.setString(4, t.getFirstName());
				stmt.setString(5, t.getLastName());
				stmt.setString(6, t.getPhone());
				stmt.setString(7, t.getSpecialty().getName());
				stmt.setBoolean(8, true);
				stmt.setBoolean(9, false);
				stmt.setString(10, "trainer");
				stmt.setString(11, t.getGender());
				
				stmt.executeUpdate();

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
			addTrainerSpecialty(t);
			return "OK";
		}
		return "";
	}

	private static void addTrainerSpecialty(Trainer t) {
		PreparedStatement stmt;
		String sql = "INSERT INTO trainer_specialty (trainer_ID, specialty_ID) VALUES (?, ?)";
		if (DBConnect.conn != null) {
			try {
				stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1, t.getTrainerID());
				stmt.setInt(2, t.getSpecialty().getSpecialtyID());
				
				stmt.executeUpdate();

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		
	}
	
	

}


