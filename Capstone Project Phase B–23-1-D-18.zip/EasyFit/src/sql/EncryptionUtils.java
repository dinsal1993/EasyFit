package sql;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import Entities.Message;
import Entities.MessageType;
import client.ClientUI;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class EncryptionUtils {
    private static final String ENCRYPTION_ALGORITHM = "AES";
    private static String ENCRYPTION_KEY = ""; 

    // Medical Field Encryption - Decryption Related Functions
    public static String encrypt(String data) throws Exception {
        Key key = generateKey();
        Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptedData = cipher.doFinal(data.getBytes());
        return Base64.getEncoder().encodeToString(encryptedData);
    }

    public static String decrypt(String encryptedData) throws Exception {
        Key key = generateKey();
        Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decryptedData = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
        return new String(decryptedData);
    }

    private static Key generateKey() {
        return new SecretKeySpec(ENCRYPTION_KEY.getBytes(), ENCRYPTION_ALGORITHM);
    }
    
    public static String createPrimeKey(String firstName, String lastName, String id) {
    	String encryptionKey = firstName + lastName + id;
    	encryptionKey = correctKeyLength(encryptionKey);
    	ENCRYPTION_KEY = encryptionKey;
    	System.out.println("in setKey(s, s, s), encKey is: " + ENCRYPTION_KEY);
    	return ENCRYPTION_KEY;
    }
    
    public static void setKey(String key) {
    	ENCRYPTION_KEY = key;
    }
    
    public static String getKey(String userID) {
    	ClientUI.chat.accept(new Message(MessageType.getDecryptionKey, userID));
    	return ENCRYPTION_KEY;
    }
    
    public static String correctKeyLength(String encryptionKey) {
		while(encryptionKey.length() < 32) {
			encryptionKey = encryptionKey + "a";
		}
		
		if(encryptionKey.length() > 32)
			encryptionKey = encryptionKey.substring(0, 32);
		
		return encryptionKey;
	}
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    // Password Hashing Related Functions
    
    private static final String HASH_ALGORITHM = "SHA-256";

    public static String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
        byte[] hashedBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
        return bytesToHex(hashedBytes);
    }

    //User MessageDigest.isEqual to prevent timing attacks
    public static boolean isPasswordValid(String password, String hashedPassword) throws NoSuchAlgorithmException {
        return password.equals(hashedPassword);
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int length = hex.length();
        byte[] bytes = new byte[length / 2];
        for (int i = 0; i < length; i += 2) {
            bytes[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                                 + Character.digit(hex.charAt(i + 1), 16));
        }
        return bytes;
    }
}