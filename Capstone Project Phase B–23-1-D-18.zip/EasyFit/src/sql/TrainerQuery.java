package sql;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import Entities.Exercise;
import Entities.Feedback;
import Entities.Person;
import Entities.Program;
import Entities.Session;
import Entities.Target;
import Entities.Trainee;
import Entities.TrainerTraineeTableRow;
import Entities.WeeklyReport;
import client.ClientController;

public class TrainerQuery {
	
	public static Map<Integer, String> fetchTrainees(int trainerID) {
		Map<Integer, String> traineeMap = null;
		String sql = "SELECT user_ID, first_name FROM user JOIN trainer_trainee ON "
				+ "user.user_ID = trainer_trainee.trainee_ID WHERE trainer_ID = ?";
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1,trainerID);
				
				ResultSet resultSet = stmt.executeQuery();
				traineeMap = new HashMap<>();
	            while (resultSet.next()) {
	                int traineeID = resultSet.getInt("user_ID");
	                String traineeName = resultSet.getString("first_name");
	                traineeMap.put(traineeID, traineeName);
	            }
	            System.out.println("in sql, " + traineeMap);

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		return traineeMap;
	}

	public static Map<String, Exercise> fetchExercises() {
	    Map<String, Exercise> exercisesMap = null;
	    Statement stmt;
	    String sql = "SELECT exercise_ID, muscle_group, name, description, alternative, video FROM exercise";
	    if (DBConnect.conn != null) {
	        try {
	            stmt = DBConnect.conn.createStatement();

	            ResultSet resultSet = stmt.executeQuery(sql);
	            exercisesMap = new HashMap<>();
	            
	            while (resultSet.next()) {
	                int exerciseID = resultSet.getInt("exercise_ID");
	                String muscleGroup = resultSet.getString("muscle_group");
	                String name = resultSet.getString("name");
	                String description = resultSet.getString("description");
	                int alternative = resultSet.getInt("alternative");
	                String video = resultSet.getString("video");
	                Exercise e = new Exercise(exerciseID, muscleGroup, name, description,
	                		alternative, null, video);
	                exercisesMap.put(name, e);
	                }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    return exercisesMap;
	}

	public static String addProgram(Program p) {
		if (DBConnect.conn != null) {
			String sql = "INSERT INTO session (trainee_ID, exercises, sets, repetitions, tag) "
			 		+ "VALUES (?, ?, ?, ?, ?)";
			for(Session s : p.getSessions()) {
						try {
							PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
							stmt.setInt(1,s.getTraineeID());
							stmt.setObject(2, serializeArrayList(s.getExercises()));
							stmt.setObject(3, serializeArrayList(s.getSets()));
							stmt.setObject(4, serializeArrayList(s.getRepetitions()));
							stmt.setString(5, s.getSessionTag());
							
							int rowsInserted = stmt.executeUpdate();
				            if (rowsInserted < 0) 
				                return "Error inserting row to database";
				            

						}catch (SQLException e) {  // catch for manager
							e.printStackTrace();
						}
					}
					return "OK";
			
		}
		return "DB connection is null";
	}
	
	// Serialize an ArrayList to a byte array
    private static byte[] serializeArrayList(ArrayList<?> list) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(list);
            oos.close();
            return baos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    

	public static String deleteProgram(int traineeID) {
		if (DBConnect.conn != null) {
	        String sql = "DELETE FROM session WHERE trainee_ID = ?";
	        try {
	            PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
	            stmt.setInt(1, traineeID);
	            
	            int rowsDeleted = stmt.executeUpdate();
	            if (rowsDeleted < 0) 
	                return "Error deleting row from database";
	            System.out.println("Rows deleted: " + rowsDeleted);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    } else {
	        System.out.println("DB connection is null");
	    }
		return "OK";
	}

	public static Map<Integer, String> getTraineeNameAll(int messageData) {
		// TODO Auto-generated method stub
		return null;
	}

	public static ArrayList<WeeklyReport> getTraineeReports(int trainerID) {
		ArrayList<WeeklyReport> arr = new ArrayList<>();
		String sql = "SELECT weekly_report.trainee_ID, sessions_performed, weight, photo, notes, year, month, week, exercises_notes, status FROM weekly_report JOIN trainer_trainee ON "
				+ "trainer_trainee.trainee_ID = weekly_report.trainee_ID AND trainer_trainee.trainer_ID = weekly_report.trainer_ID WHERE trainer_trainee.trainer_ID = ?";
		
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1,trainerID);
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	                int traineeID = resultSet.getInt("trainee_ID");
	                int sessions_performed = resultSet.getInt("sessions_performed");
	                int weight = resultSet.getInt("weight");
	                byte[] photo = resultSet.getBytes("photo");
	                String notes = resultSet.getString("notes");
	                int year = resultSet.getInt("year");
	                int month = resultSet.getInt("month");
	                int week = resultSet.getInt("week");
	                Map<String, String> exercises_notes =deserializeMap(resultSet.getBytes("exercises_notes"));
	                String status = resultSet.getString("status");
	                WeeklyReport wr = new WeeklyReport(traineeID, sessions_performed, weight, photo, notes, year, month, week, exercises_notes, -1);
	                wr.setStatus(status);
	                arr.add(wr);
	            }

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		return arr;
	}
	
	private static Map<String, String> deserializeMap(byte[] serializedData) {
	    try {
	        ByteArrayInputStream bais = new ByteArrayInputStream(serializedData);
	        ObjectInputStream ois = new ObjectInputStream(bais);
	        Object deserializedObject = ois.readObject();
	        ois.close();
	        
	        if (deserializedObject instanceof Map) {
	            return (Map<String, String>) deserializedObject;
	        }
	    } catch (IOException | ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    
	    return null;
	}

	public static String addFeedback(Feedback fb) {
		if (DBConnect.conn != null) {
			String sql = "INSERT INTO feedback (trainee_ID, notes, exercises_notes, year, month, week) "
			 		+ "VALUES (?, ?, ?, ?, ?, ?)";
			try {
					PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
					stmt.setInt(1,fb.getTraineeID());
					stmt.setString(2, fb.getNotes());
					stmt.setString(3, fb.getExercisesNotes());
					stmt.setInt(4, fb.getYear());
					stmt.setInt(5,fb.getMonth());
					stmt.setInt(6,fb.getWeek());
							
					stmt.executeUpdate();
					
					updateReportStatusClosed(fb);
			}catch (SQLException e) {  // catch for manager
					e.printStackTrace();
			}
			return "Feedback Sent";
			
		}
		return "DB connection is null";
	}

	private static void updateReportStatusClosed(Feedback fb) {
		if (DBConnect.conn != null) {
			String sql = "UPDATE weekly_report SET status = ? WHERE trainee_ID = ? AND year = ? AND month = ? AND week = ?";
			try {
					PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
					stmt.setString(1,"closed");
					stmt.setInt(2, fb.getTraineeID());
					stmt.setInt(3, fb.getYear());
					stmt.setInt(4,fb.getMonth());
					stmt.setInt(5,fb.getWeek());		
					stmt.executeUpdate();
			}catch (SQLException e) {  // catch for manager
					e.printStackTrace();
			}
		}
		
	}

	public static ArrayList<TrainerTraineeTableRow> getTraineeRowData(int trainerID) {
		ArrayList<TrainerTraineeTableRow> arr = new ArrayList<>();
		String sql = "SELECT user_ID, first_name, last_name, email, phone, age, gender FROM user JOIN trainer_trainee ON "
		        + "user.user_ID = trainer_trainee.trainee_ID "
		        + "WHERE trainer_trainee.trainer_ID = ?;";
		
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1,trainerID);
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	                int traineeID = resultSet.getInt("user_ID");
	                String first_name = resultSet.getString("first_name");
	                String last_name = resultSet.getString("last_name");
	                String email = resultSet.getString("email");
	                String phone = resultSet.getString("phone");
	                int age = resultSet.getInt("age");
	                String gender = resultSet.getString("gender");
	                
	                arr.add(new TrainerTraineeTableRow(traineeID, first_name + " " + last_name, phone, email, age, gender));
	            }

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		return arr;
	}

	public static ArrayList getTraineeFullData(int traineeID) {
		ArrayList arr = new ArrayList<>();
		String sql = "SELECT user.user_ID, user.address, user.weight, user.height, user.birth_year, user.birth_month,"
				+ " user.photo, user.medical, user.email, user.first_name, user.last_name, user.phone, user.gender,"
				+ " target.goal, target.sessions_per_week, target.session_duration, target.activity_level"
				+ " FROM user"
				+ " INNER JOIN target ON user.user_ID = target.user_ID WHERE user.user_ID = ?";
		
		if (DBConnect.conn != null) {
			try {
				PreparedStatement stmt = DBConnect.conn.prepareStatement(sql);
				stmt.setInt(1,traineeID);
				
				ResultSet resultSet = stmt.executeQuery();
	            while (resultSet.next()) {
	            	
	                int id = resultSet.getInt("user_ID");
	                String adress = resultSet.getString("address");
	                int weight = resultSet.getInt("weight");
	                int height = resultSet.getInt("height");
	                int birthYear = resultSet.getInt("birth_year");
	                int birthMonth = resultSet.getInt("birth_month");
	                byte[] photo = resultSet.getBytes("photo");
	                String medical = resultSet.getString("medical");
	                String email = resultSet.getString("email");
	                String firstName = resultSet.getString("first_name");
	                String lastName = resultSet.getString("last_name");
	                String phone = resultSet.getString("phone");
	                String gender = resultSet.getString("gender");
	                String goal = resultSet.getString("goal");
	                int sessions_per_week = resultSet.getInt("sessions_per_week");
	                int session_duration = resultSet.getInt("session_duration");
	                int activity_level = resultSet.getInt("activity_level");
	                
	                Trainee t = new Trainee(id, email, "", firstName, lastName, phone, adress, weight, height, birthYear, 
	                		birthMonth, 0, photo, medical, false, false, gender);
	                Target tar = new Target(id, goal, sessions_per_week, session_duration, activity_level);
	                
	                arr.add(t);
	                arr.add(tar);

	            }

			}catch (SQLException e) { // catch for manager
				e.printStackTrace();
			}
		}
		return arr;
	}
}
