package server;

// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Map;

import Entities.Exercise;
import Entities.Feedback;
import Entities.Message;
import Entities.MessageType;
import Entities.Person;
import Entities.Program;
import Entities.Request;
import Entities.Session;
import Entities.Target;
import Entities.Trainee;
import Entities.Trainer;
import Entities.TrainerTraineeTableRow;
import Entities.WeeklyReport;
import sql.ManagerQuery;
import sql.TraineeQuery;
import sql.TrainerQuery;
import sql.UserQuery;
import client.ClientController;
import client.ClientUI;
import client.gui.controllers.AbstractController;
import client.gui.controllers.ManagerHandlingTraineeRequestController;
import server.ClientConnection;
import server.gui.controllers.ServerUIFController;
import ocsf.server.*;

/**
 * This class overrides some of the methods in the abstract 
 * superclass in order to give more functionality to the server.
*/ 
public class EchoServer extends AbstractServer 
{
  //Class variables *************************************************
  
  /**
   * The default port to listen on.
   */
  final public static int DEFAULT_PORT = 5555;
	public static ServerUIFController serverUIFController;
	public static ClientController ClientController;
	
  public EchoServer(int port) 
  {
    super(port);
  }
  
  @Override
	protected void clientConnected(ConnectionToClient client) {
		super.clientConnected(client);
		System.out.println(client + " connected !");
	}

  public void handleMessageFromClient(Object msg, ConnectionToClient client) {
	  System.out.println("in echo start");
	Message message = (Message) msg;
	System.out.println(("MessageType: " + message.getMessageType() + " Data: " + message.getMessageData() + " from " + client));
	Message messageFromServer = null;
	switch (message.getMessageType())
	{
		case login: {
			String[] info = ((String) message.getMessageData()).split("!");
			String result = "";
			try {
				result = UserQuery.login(info[0], info[1]);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(result.equals("Invalid email")) 
				messageFromServer = new Message(MessageType.login, "Invalid email");
			else if(result.equals("UserAlreadyConnected"))
				messageFromServer = new Message(MessageType.login, "Already connected");
			else if(result.equals("Invalid password"))
				messageFromServer = new Message(MessageType.login, "Invalid password");
			else
				//result = "userID" + "!" + "role"
				messageFromServer = new Message(MessageType.login, result);
			break;
		}
		case logout: {
			int userID = (int) message.getMessageData();
			UserQuery.updateOnline(String.valueOf(userID), false);
			AbstractController.returnMsg = "OK";
			messageFromServer = new Message(MessageType.logout, "OK");
			break;
		}
		case createTrainee: {
			Trainee trainee = (Trainee) ((ArrayList<Object>) message.getMessageData()).get(0);
			Target target = (Target) ((ArrayList<Object>) message.getMessageData()).get(1);
			String result = UserQuery.createTrainee(trainee, target);
			messageFromServer = new Message(MessageType.createTrainee, result);
			break;
		}
		case getDecryptionKey:{
			System.out.println("in getDecryptionKey server");
			String result = UserQuery.getDecryptionKey((String) message.getMessageData());
			System.out.println("send message to client finish decrypt key");
			messageFromServer = new Message(MessageType.getDecryptionKey, result);
			break;
		}
		case fetchTrainees: {
			
			int trainerID = (int) ((ArrayList)message.getMessageData()).get(0);
			Map<Integer, String> traineeMap = TrainerQuery.fetchTrainees(trainerID);
			
			ArrayList info = new ArrayList<>();
			info.add(traineeMap);
			info.add((String) ((ArrayList) message.getMessageData()).get(1));
			messageFromServer = new Message(MessageType.fetchTrainees, info);
			break;
		}
		
		case fetchExercises: {
			Map<String, Exercise> exerciseMap = TrainerQuery.fetchExercises();
			ArrayList info = new ArrayList<>();
			info.add(exerciseMap);
			info.add((String) message.getMessageData());
			messageFromServer = new Message(MessageType.fetchExercises, info);
			break;
		}
		case addProgram: {
			Program p = (Program) message.getMessageData();
			String result = TrainerQuery.addProgram(p);
			messageFromServer = new Message(MessageType.addProgram, result);
			break;
		}
		case deleteProgram: {
			int traineeID = (int) message.getMessageData();
			String result = TrainerQuery.deleteProgram(traineeID);
			messageFromServer = new Message(MessageType.deleteProgram, "OK");
			break;
		}
		case getProgram: {
			System.out.println("in echo get program");
			ArrayList info = new ArrayList<>();
			Map<String, Session> sessions =
					TraineeQuery.getProgram((int)((ArrayList) message.getMessageData()).get(0));
			info.add(sessions);
			info.add((String)((ArrayList)message.getMessageData()).get(1));
			messageFromServer = new Message(MessageType.getProgram, info);
			break;
		}
		case getName: {
			String name = TraineeQuery.getName((int) ((ArrayList) message.getMessageData()).get(0));

			ArrayList info = new ArrayList();
	    	info.add(name);
	    	info.add((String) ((ArrayList)message.getMessageData()).get(1));

			messageFromServer = new Message(MessageType.getName, info);
			break;
		}
		case addWeeklyReport: {
			TraineeQuery.addWeeklyReport((WeeklyReport) message.getMessageData());
			messageFromServer = new Message(MessageType.addWeeklyReport, "OK");
			break;
		}
		case getTraineeFeedbacks: {
			ArrayList<Feedback> arr = TraineeQuery.getTraineeFeedbacks((int) message.getMessageData());
			messageFromServer = new Message(MessageType.getTraineeFeedbacks, arr);
			break;
		}
		case addRequest: {
			String result = TraineeQuery.addRequest((Request) message.getMessageData());
			messageFromServer = new Message(MessageType.addRequest, result);
			break;
		}
		case getTraineeNameAll: {
			Map<Integer, String> names = TrainerQuery.getTraineeNameAll((int) message.getMessageData());
			messageFromServer = new Message(MessageType.getTraineeNameAll, names);
			break;
		}
		case getTraineeReports: {
			ArrayList<WeeklyReport> reports = TrainerQuery.getTraineeReports((int) message.getMessageData());
			messageFromServer = new Message(MessageType.getTraineeReports, reports);
			break;
		}
		case getTrainerID: {
			int id = TraineeQuery.getTrainerID((int)((ArrayList) message.getMessageData()).get(0));
			ArrayList info = new ArrayList();
    		info.add(id);
    		info.add((String)((ArrayList) message.getMessageData()).get(1));
			messageFromServer = new Message(MessageType.getTrainerID, info);
			break;
		}
		case sendFeedback: {
			String result = TrainerQuery.addFeedback((Feedback) message.getMessageData());
			messageFromServer = new Message(MessageType.sendFeedback, result);
			break;
		}
		case getTraineesRowData: {
			ArrayList<TrainerTraineeTableRow> arr = TrainerQuery.getTraineeRowData((int) message.getMessageData());
			messageFromServer = new Message(MessageType.getTraineesRowData, arr);
			break;
		}
		case getTraineesFullData: {
			ArrayList arr = TrainerQuery.getTraineeFullData(Integer.parseInt((String) message.getMessageData()));
			messageFromServer = new Message(MessageType.getTraineesFullData, arr);
			break;
		}
		case getAllRequest: {
			ArrayList<Request> arr = ManagerQuery.getAllRequest();
			messageFromServer = new Message(MessageType.getAllRequest, arr);
			break;
		}
		case getRequest: {
			System.out.println("in getRequest eho");
			Request r = ManagerQuery.getRequest((int) ((ArrayList)message.getMessageData()).get(0));
			String place = (String) ((ArrayList)message.getMessageData()).get(1);
			ArrayList info = new ArrayList<>();
			info.add(r);
			info.add(place);
			System.out.println("echo: request: " + r);
			messageFromServer = new Message(MessageType.getRequest, info);
			break;
		}
		case getTrainersByTarget: {
			
			ArrayList<Trainer> arr = ManagerQuery.getTrainersByTarget((String) ((ArrayList)message.getMessageData()).get(0));
			ArrayList info = new ArrayList<>();
			info.add(arr);
			info.add((String) ((ArrayList)message.getMessageData()).get(1));
			messageFromServer = new Message(MessageType.getTrainersByTarget, info);
			break;
		}
		case getTrainersByTrainer: {
			ArrayList<Trainer> arr = ManagerQuery.getTrainersByTrainer((int) message.getMessageData());
			messageFromServer = new Message(MessageType.getTrainersByTrainer, arr);
			break;
		}
		case confirmRequestTarget: {
			Request r = (Request)((ArrayList)message.getMessageData()).get(0);
			String trainer = (String)((ArrayList)message.getMessageData()).get(1);
			int trainerID = Integer.parseInt(trainer);
			String result = ManagerQuery.confirmRequestTarget(r, trainerID);
			messageFromServer = new Message(MessageType.confirmRequestTarget, result);
			break;
		}
		case confirmRequestTrainer: {
			Request r = (Request)((ArrayList)message.getMessageData()).get(0);
			String trainer = (String)((ArrayList)message.getMessageData()).get(1);
			int trainerID = Integer.parseInt(trainer);
			String result = ManagerQuery.confirmRequestTrainer(r, trainerID);
			messageFromServer = new Message(MessageType.confirmRequestTrainer, result);
			break;
		}
		case rejectRequest: {
			String result = ManagerQuery.rejectRequest((Request)message.getMessageData());
			messageFromServer = new Message(MessageType.rejectRequest, result);
			break;
		}
		case confirmRequestSignUp: {
			System.out.println("in echo, confSign");
			Request r = (Request) ((ArrayList)message.getMessageData()).get(0);
			System.out.println("in echo, confSign1");
			int traineeID = (int) ((ArrayList)message.getMessageData()).get(1);
			System.out.println("in echo, confSign2");
			int trainerID = (int) ((ArrayList)message.getMessageData()).get(2);
			System.out.println("in echo, confSign3");
			String result = ManagerQuery.confirmRequestSignup(r, traineeID, trainerID);
			System.out.println("in echo, confSign4");
			messageFromServer = new Message(MessageType.confirmRequestSignUp, result);
			break;
		}
		case getSpecialtyList: {
			Map<String,Integer> arr = ManagerQuery.getSpecialtyList();
			messageFromServer = new Message(MessageType.getSpecialtyList, arr);
			break;
		}
		case addNewTrainer: {
			String result = UserQuery.addTrainer((Trainer) message.getMessageData());
			messageFromServer = new Message(MessageType.addNewTrainer, result);
			break;
		}
		case getTrainers: {
			Map<String, Integer> arr = ManagerQuery.getTrainers();
			System.out.println("client: trainers: " +arr );
			messageFromServer = new Message(MessageType.getTrainers, arr);
			break;
		}
		case removeTraineeFromTrainer: {
			String result = ManagerQuery.removeTraineeFromTrainer((int) message.getMessageData());
			messageFromServer = new Message(MessageType.removeTraineeFromTrainer, result);
			break;
		}
		case addTraineeToTrainer: {
			int trainerID = (int)((ArrayList)message.getMessageData()).get(0);
			int traineeID = (int)((ArrayList)message.getMessageData()).get(1);
			String result = ManagerQuery.addTraineeToTrainer(trainerID, traineeID);
			messageFromServer = new Message(MessageType.addTraineeToTrainer, result);
			break;
		}
		case deleteUser: {
			String result = ManagerQuery.deleteUser((int) message.getMessageData());
			messageFromServer = new Message(MessageType.deleteUser, result);
			break;
		}
	}//END switch
	
	try {
		System.out.println("msg from server is: " + messageFromServer.getMessageData());
		client.sendToClient(messageFromServer);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//this.sendToAllClients(messageFromServer);

  }
  
  /**
   * This method overrides the one in the superclass.  Called
   * when the server starts listening for connections.
   */
  protected void serverStarted()
  {
    System.out.println
      ("Server listening for connections on port " + getPort());
  }
  
  /**
   * This method overrides the one in the superclass.  Called
   * when the server stops listening for connections.
   */
  protected void serverStopped()
  {
    System.out.println
      ("Server has stopped listening for connections.");
  }
  
  
  //Class methods ***************************************************
  
  /**
   * This method is responsible for the creation of 
   * the server instance (there is no UI in this phase).
   *
   * @param args[0] The port number to listen on.  Defaults to 5555 
   *          if no argument is entered.
   */
  public static void main(String[] args) 
  {
    int port = 0; //Port to listen on

    try
    {
      port = Integer.parseInt(args[0]); //Get port from command line
    }
    catch(Throwable t)
    {
      port = DEFAULT_PORT; //Set port to 5555
    }
	
    EchoServer sv = new EchoServer(port);
    
    try 
    {
      sv.listen(); //Start listening for connections
    } 
    catch (Exception ex) 
    {
      System.out.println("ERROR - Could not listen for clients!");
    }
  }
}
//End of EchoServer class
