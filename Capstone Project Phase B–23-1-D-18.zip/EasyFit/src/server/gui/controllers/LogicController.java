package server.gui.controllers;

public class LogicController {

}
