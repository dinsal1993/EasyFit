package Entities;

import java.io.Serializable;

public class Target implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int userID;
	private String goal;
	private int sessionsPerWeek;
	private int sessionDuration;
	private int activityLevel;
	
	public Target(int userID, String goal, int sessionsPerWeek, int sessionDuration, int activityLevel) {
		super();
		this.userID = userID;
		this.goal = goal;
		this.sessionsPerWeek = sessionsPerWeek;
		this.sessionDuration = sessionDuration;
		this.activityLevel = activityLevel;
	}
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int targetID) {
		this.userID = targetID;
	}
	public String getGoal() {
		return goal;
	}
	public void setGoal(String goal) {
		this.goal = goal;
	}
	public int getSessionsPerWeek() {
		return sessionsPerWeek;
	}
	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}
	public int getSessionDuration() {
		return sessionDuration;
	}
	public void setSessionDuration(int sessionDuration) {
		this.sessionDuration = sessionDuration;
	}
	public int getActivityLevel() {
		return activityLevel;
	}
	public void setActivityLevel(int activityLevel) {
		this.activityLevel = activityLevel;
	}

	@Override
	public String toString() {
		return "Target [userID=" + userID + ", goal=" + goal + ", sessionsPerWeek=" + sessionsPerWeek
				+ ", sessionDuration=" + sessionDuration + ", activityLevel=" + activityLevel + "]";
	}
	
	

}
