package Entities;

import java.io.Serializable;

public class Person implements Serializable {
	
	private static final long serialVersionUID = 1L;
	protected int userID;
	protected String email;
	protected String password;
	protected String firstName;
	protected String lastName;
	protected String phone;
	protected String role;
	protected boolean online;
	protected String Gender;
	
	public Person(String email, String password, String firstName, String lastName,
			String phone, boolean online, String role, String gender) {
		this.email = email;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.online = online;
		this.role = role;
		this.Gender = gender;
	}

	public Person() {
		// TODO Auto-generated constructor stub
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public boolean getOnline() {
		return online;
	}
	public void setOnline(boolean online) {
		this.online = online;
	}
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int id) {
		this.userID = id;
	}

	@Override
	public String toString() {
		return "Person [email=" + email + ", password=" + password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", phone=" + phone + "]";
	}
	
	
}
