package Entities;

import java.io.Serializable;

public class Trainer extends Person implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int trainerID;
	private Specialty specialty;
	
	public Trainer(int trainerID, String email, String password, String firstName, String lastName, String phone,
			Specialty specialty, boolean online, String gender) {
		super(email,password, firstName, lastName, phone, online, "trainer", gender);
		this.trainerID = trainerID;
		this.specialty = specialty;
	}
	
	public int getTrainerID() {
		return trainerID;
	}
	public void setTrainerID(int trainerID) {
		this.trainerID = trainerID;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Specialty getSpecialty() {
		return specialty;
	}
	public void setSpecialty(Specialty specialty) {
		this.specialty = specialty;
	}
	
	

}
