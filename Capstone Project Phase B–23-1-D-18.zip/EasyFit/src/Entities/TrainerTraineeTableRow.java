package Entities;

import java.io.Serializable;

public class TrainerTraineeTableRow implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int traineeID;
	private String traineeName;
	private String phone;
	private String email;
	private int age;
	private String gender;
	
	public TrainerTraineeTableRow(int traineeID, String traineeName, String phone, String email, int age, String gender) {
		super();
		this.traineeID = traineeID;
		this.traineeName = traineeName;
		this.phone = phone;
		this.email = email;
		this.age = age;
		this.gender = gender;
	}

	public int getTraineeID() {
		return traineeID;
	}

	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "TrainerTraineeTableRow [traineeID=" + traineeID + ", traineeName=" + traineeName + ", phone=" + phone
				+ ", email=" + email + ", age=" + age + ", gender=" + gender + "]";
	}
	
	
}
