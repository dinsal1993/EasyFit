package Entities;

import java.io.Serializable;

public class TraineeTarget implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int traineeID;
	private int targetID;
	
	public TraineeTarget(int traineeID, int targetID) {
		super();
		this.traineeID = traineeID;
		this.targetID = targetID;
	}
	
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	public int getTargetID() {
		return targetID;
	}
	public void setTargetID(int targetID) {
		this.targetID = targetID;
	}
	
	

}
