package Entities;

import java.io.Serializable;

public class WeeklyExerciseReportList implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int reportID;
	private int traineeID;
	private int exerciseID;
	
	public WeeklyExerciseReportList(int reportID, int traineeID, int exerciseID) {
		super();
		this.reportID = reportID;
		this.traineeID = traineeID;
		this.exerciseID = exerciseID;
	}
	
	public int getReportID() {
		return reportID;
	}
	public void setReportID(int reportID) {
		this.reportID = reportID;
	}
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	public int getExerciseID() {
		return exerciseID;
	}
	public void setExerciseID(int exerciseID) {
		this.exerciseID = exerciseID;
	}
	
	

}
