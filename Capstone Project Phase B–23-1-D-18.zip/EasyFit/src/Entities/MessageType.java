package Entities;

public enum MessageType {

	/*User Message*/	
	login, logout, getDecryptionKey, 
	/*Trainee Message*/
	
	
	/*Trainer Message*/
	 createTrainee, fetchTrainees,
	
	/*Manager Message*/
	
	/*Error*/
	Error, Success, fetchExercises, addProgram, deleteProgram, getProgram, getName, addWeeklyReport, getTrainerID, getTraineeFeedbacks, addRequest, getTraineeReports, getTraineeNameAll, sendFeedback, getTraineesFullData, getTraineesRowData, getAllRequest, getRequest, getTrainersByTarget, getTrainersByTrainer, confirmRequestTarget, confirmRequestTrainer, rejectRequest, confirmRequestSignUp, getSpecialty, getSpecialtyList, addNewTrainer, getTrainers, removeTraineeFromTrainer, addTraineeToTrainer, deleteUser
}
