package Entities;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Map;



public class WeeklyReport implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int reportID;
	private int traineeID;
	private int sessionsPerformed;
	private int weight;
	private byte[] photo;
	private String notes;
	private int year;
	private int month;
	private int week;
	private Map<String, String> exerciseNotes;
	private String status;
	private int trainerID;
	
	public WeeklyReport(int traineeID, int sessionsPerformed, int weight, byte[] photo, String notes,
			int year, int month, int week, Map<String, String> exerciseNotes, int trainerID) {
		this.traineeID = traineeID;
		this.sessionsPerformed = sessionsPerformed;
		this.weight = weight;
		this.photo = photo;
		this.notes = notes;
		this.year = year;
		this.month = month;
		this.week = week;
		this.exerciseNotes = exerciseNotes;
		this.status = "open";
		this.trainerID = trainerID;
	}
	public int getReportID() {
		return reportID;
	}
	public void setReportID(int reportID) {
		this.reportID = reportID;
	}
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	public int getSessionsPerformed() {
		return sessionsPerformed;
	}
	public void setSessionsPerformed(int sessionsPerformed) {
		this.sessionsPerformed = sessionsPerformed;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public byte[] getPhoto() {
		return photo;
	}
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getWeek() {
		return week;
	}
	public void setWeek(int week) {
		this.week = week;
	}
	public Map<String, String> getExerciseNotes() {
		return exerciseNotes;
	}
	public void setExerciseNotes(Map<String, String> exerciseNotes) {
		this.exerciseNotes = exerciseNotes;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTrainerID() {
		return trainerID;
	}
	public void setTrainerID(int trainerID) {
		this.trainerID = trainerID;
	}
	
	@Override
	public String toString() {
		return "WeeklyReport [reportID=" + reportID + ", traineeID=" + traineeID + ", sessionsPerformed="
				+ sessionsPerformed + ", weight=" + weight + ", photo=" + Arrays.toString(photo) + ", notes=" + notes
				+ ", year=" + year + ", month=" + month + ", week=" + week + ", exerciseNotes=" + exerciseNotes + ", status=" + status +"]";
	}
	
	

}
