package Entities;

import javafx.scene.control.Hyperlink;

//This class represents a row in the table in the CreateTrainingPlan screen
public class TrainingPlanTableRow {
	private String session;
	private String exercise;
	private String sets;
	private String reps;
	private Hyperlink linkYoutube;
	
	
	public TrainingPlanTableRow(String session, String exercise, String sets, String reps) {
		super();
		this.session = session;
		this.exercise = exercise;
		this.sets = sets;
		this.reps = reps;
	}
	
	public TrainingPlanTableRow(String session, String exercise, String sets, String reps,
			Hyperlink link) {
		super();
		this.session = session;
		this.exercise = exercise;
		this.sets = sets;
		this.reps = reps;
		this.linkYoutube = link;
	}
	public String getSession() {
		return session;
	}
	public void setSession(String session) {
		this.session = session;
	}
	public String getExercise() {
		return exercise;
	}
	public void setExercise(String exercise) {
		this.exercise = exercise;
	}
	public String getSets() {
		return sets;
	}
	public void setSets(String sets) {
		this.sets = sets;
	}
	public String getReps() {
		return reps;
	}
	public void setReps(String reps) {
		this.reps = reps;
	}
	public Hyperlink getLink() {
		return linkYoutube;
	}
	public void setLink(Hyperlink link) {
		this.linkYoutube = link;
	}
}
