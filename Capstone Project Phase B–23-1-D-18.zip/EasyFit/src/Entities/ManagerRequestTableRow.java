package Entities;

public class ManagerRequestTableRow {
	private int requestID;
	private int traineeID;
	private int trainer;
	private String type;
	private String status;
	
	public ManagerRequestTableRow(int requestID, int traineeID, int trainer, String type, String status) {
		super();
		this.requestID = requestID;
		this.traineeID = traineeID;
		this.trainer = trainer;
		this.type = type;
		this.status = status;
	}

	public int getRequestID() {
		return requestID;
	}

	public void setRequestID(int requestID) {
		this.requestID = requestID;
	}

	public int getTraineeID() {
		return traineeID;
	}

	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}

	public int getTrainer() {
		return trainer;
	}

	public void setTrainer(int trainer) {
		this.trainer = trainer;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ManagerRequestTableRow [traineeID=" + traineeID + ", trainerName=" + trainer + ", request="
				+ type + ", status=" + status + "]";
	}
}
