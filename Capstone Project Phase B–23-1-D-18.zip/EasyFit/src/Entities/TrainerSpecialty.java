package Entities;

import java.io.Serializable;

public class TrainerSpecialty implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int trainerID;
	private int specialtyID;
	
	public TrainerSpecialty(int trainerID, int specialtyID) {
		super();
		this.trainerID = trainerID;
		this.specialtyID = specialtyID;
	}
	
	public int getTrainerID() {
		return trainerID;
	}
	public void setTrainerID(int trainerID) {
		this.trainerID = trainerID;
	}
	public int getSpecialtyID() {
		return specialtyID;
	}
	public void setSpecialtyID(int specialtyID) {
		this.specialtyID = specialtyID;
	}
	
	

}
