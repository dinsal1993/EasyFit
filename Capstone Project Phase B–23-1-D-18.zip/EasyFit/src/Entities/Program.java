package Entities;

import java.io.Serializable;
import java.util.ArrayList;

public class Program implements Serializable {
	private static final long serialVersionUID = 1L;
	private int traineeID;
	private ArrayList<Session> sessions;
	
	public Program(int traineeID, ArrayList<Session> sessions) {
		this.traineeID = traineeID;
		this.sessions = sessions;
	}
	
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	
	public ArrayList<Session> getSessions() {
		return sessions;
	}
	public void setSessions(ArrayList<Session> sessions) {
		this.sessions = sessions;
	}
	
	@Override
	public String toString() {
		return "[traineeID = " + traineeID + ", sessions = " + sessions + "]";
	}
	
}
