package Entities;

import java.io.Serializable;

public class Feedback implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int feedbackID;
	private int traineeID;
	private String exercisesNotes;
	private String notes;
	private int year;
	private int month;
	private int week;
	
	public Feedback(int traineeID, String exercisesNotes, String notes, int year, int month, int week) {
		this.traineeID = traineeID;
		this.exercisesNotes = exercisesNotes;
		this.notes = notes;
		this.year = year;
		this.month = month;
		this.week = week;
	}
	public int getFeedbackID() {
		return feedbackID;
	}
	public void setFeedbackID(int feedbackID) {
		this.feedbackID = feedbackID;
	}
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	public String getExercisesNotes() {
		return exercisesNotes;
	}
	public void setExercisesNotes(String exercisesNotes) {
		this.exercisesNotes = exercisesNotes;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getWeek() {
		return week;
	}
	public void setWeek(int week) {
		this.week = week;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Feedback [feedbackID=" + feedbackID + ", traineeID=" + traineeID + ", exercisesNotes=" + exercisesNotes
				+ ", notes=" + notes + ", year=" + year + ", month=" + month + ", week=" + week + "]";
	}
	
	
	
}
