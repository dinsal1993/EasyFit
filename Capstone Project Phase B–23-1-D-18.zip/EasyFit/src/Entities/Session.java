package Entities;

import java.io.Serializable;
import java.util.ArrayList;

public class Session implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int sessionID;
	private String sessionTag;
	private int traineeID;
	private ArrayList<Exercise> exercises;
	private ArrayList<String> sets;
	private ArrayList<String> repetitions;
	
	public Session(int traineeID, ArrayList<Exercise> exercises, ArrayList<String> sets,
			ArrayList<String> repetitions, String tag) {
		this.traineeID = traineeID;
		this.exercises = exercises;
		this.sets = sets;
		this.repetitions = repetitions;
		this.sessionTag = tag;
	}
	
	public int getSessionID() {
		return sessionID;
	}
	public void setSessionID(int sessionID) {
		this.sessionID = sessionID;
	}
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	public ArrayList<Exercise> getExercises() {
		return exercises;
	}
	public void setExercises(ArrayList<Exercise> exercises) {
		this.exercises = exercises;
	}
	public ArrayList<String> getSets() {
		return sets;
	}
	public void setSets(ArrayList sets) {
		this.sets = sets;
	}
	public ArrayList<String> getRepetitions() {
		return repetitions;
	}
	public void setRepetitions(ArrayList repetitions) {
		this.repetitions = repetitions;
	}
	
	public String getSessionTag() {
		return sessionTag;
	}
	public void setSessionTag(String tag) {
		this.sessionTag = tag;
	}

	@Override
	public String toString() {
		return "Session [sessionID=" + sessionID + ", sessionTag=" + sessionTag + ", traineeID=" + traineeID
				+ ", exercises=" + exercises + ", sets=" + sets + ", repetitions=" + repetitions + "]";
	}
	
	

}
