package Entities;

import java.io.Serializable;

public class ExerciseReport implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int exerciseID;
	private int reportID;
	private String text;
	
	public ExerciseReport(int exerciseID, int reportID, String text) {
		super();
		this.exerciseID = exerciseID;
		this.reportID = reportID;
		this.text = text;
	}
	
	public int getExerciseID() {
		return exerciseID;
	}
	public void setExerciseID(int exerciseID) {
		this.exerciseID = exerciseID;
	}
	public int getReportID() {
		return reportID;
	}
	public void setReportID(int reportID) {
		this.reportID = reportID;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	

}
