package Entities;

import java.io.Serializable;

public class TrainerTrainee implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int trainerID;
	private int traineeID;
	
	public TrainerTrainee(int trainerID, int traineeID) {
		super();
		this.trainerID = trainerID;
		this.traineeID = traineeID;
	}
	
	public int getTrainerID() {
		return trainerID;
	}
	public void setTrainerID(int trainerID) {
		this.trainerID = trainerID;
	}
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	
	

}
