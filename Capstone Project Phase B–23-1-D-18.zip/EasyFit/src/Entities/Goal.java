package Entities;

public enum Goal {
	Mass, Cut, lean, General_Health, Flexibility, Calisthenics
}
