package Entities;

import java.io.Serializable;

import javafx.scene.image.Image;

public class Exercise implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int exerciseID;
	private String muscleGroup;
	private String name;
	private String description;
	private int alternative;
	private byte[] photo;
	private String video;
	
	public Exercise(int exerciseID, String muscleGroup, String name, String description, int alternative, byte[] photo,
			String video) {
		super();
		this.exerciseID = exerciseID;
		this.muscleGroup = muscleGroup;
		this.name = name;
		this.description = description;
		this.alternative = alternative;
		this.photo = photo;
		this.video = video;
	}

	public int getExerciseID() {
		return exerciseID;
	}

	public void setExerciseID(int exerciseID) {
		this.exerciseID = exerciseID;
	}

	public String getMuscleGroup() {
		return muscleGroup;
	}

	public void setMuscleGroup(String muscleGroup) {
		this.muscleGroup = muscleGroup;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getAlternative() {
		return alternative;
	}

	public void setAlternative(int alternative) {
		this.alternative = alternative;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public String getVideo() {
		return video;
	}

	public void setVideo(String video) {
		this.video = video;
	}

	@Override
	public String toString() {
		return "Exercise [exerciseID=" + exerciseID + ", muscleGroup=" + muscleGroup + ", name=" + name
				+ ", description=" + description + ", alternative=" + alternative + ", photo=" + photo + ", video="
				+ video + "]";
	}
	
	
	

}
