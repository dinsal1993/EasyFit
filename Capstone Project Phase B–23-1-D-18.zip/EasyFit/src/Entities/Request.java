package Entities;

import java.io.Serializable;

public class Request implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int requestID;
	private int traineeID;
	private String type;
	private String details;
	private String goal;
	private int sessionsPerWeek;
	private int sessionDuration;
	private int activityLevel;
	private String status;
	
	public Request(int requestID, int traineeID, String type, String details, String goal, int sessionsPerWeek,
			int sessionDuration, int activityLevel, String status) {
		this.traineeID = traineeID;
		this.type = type;
		this.details = details;
		this.goal = goal;
		this.sessionsPerWeek = sessionsPerWeek;
		this.sessionDuration = sessionDuration;
		this.activityLevel = activityLevel;
		this.status = status;
		this.requestID = requestID;
	}
	
	public Request(int traineeID, String type, String details, String goal, int sessionsPerWeek,
			int sessionDuration, int activityLevel) {
		this.traineeID = traineeID;
		this.type = type;
		this.details = details;
		this.goal = goal;
		this.sessionsPerWeek = sessionsPerWeek;
		this.sessionDuration = sessionDuration;
		this.activityLevel = activityLevel;
		this.status = "open";
	}

	public int getRequestID() {
		return requestID;
	}

	public void setRequestID(int requestID) {
		this.requestID = requestID;
	}

	public int getTraineeID() {
		return traineeID;
	}

	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getGoal() {
		return goal;
	}

	public void setGoal(String goal) {
		this.goal = goal;
	}

	public int getSessionsPerWeek() {
		return sessionsPerWeek;
	}

	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}

	public int getSessionDuration() {
		return sessionDuration;
	}

	public void setSessionDuration(int sessionDuration) {
		this.sessionDuration = sessionDuration;
	}

	public int getActivityLevel() {
		return activityLevel;
	}

	public void setActivityLevel(int activityLevel) {
		this.activityLevel = activityLevel;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Request [requestID=" + requestID + ", traineeID=" + traineeID + ", type=" + type + ", details="
				+ details + ", goal=" + goal + ", sessionsPerWeek=" + sessionsPerWeek + ", sessionDuration="
				+ sessionDuration + ", activityLevel=" + activityLevel + "]";
	}

	
}
