package Entities;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.Serializable;

import javax.imageio.ImageIO;

import javafx.embed.swing.SwingFXUtils;


public class Trainee extends Person implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int userID;
	private String address;
	private int weight;
	private int height;
	private int birthYear;
	private int birthMonth;
	private int age;
	private byte[] photo;
	private String medical;
	private boolean approved;
	private String gender;

	public Trainee(int userID, String email, String password, String firstName, String lastName, String phone,
			String address, int weight, int height,int birthYear, int birthMonth, int age, byte[] photo, String medical,
			boolean approved, boolean online, String gender) {
		super(email,password, firstName, lastName, phone,online, "trainee", gender);
		this.userID = userID;
		this.address = address;
		this.weight = weight;
		this.height = height;
		this.birthYear = birthYear;
		this.birthMonth = birthMonth;
		this.age = age;
		this.photo = photo;
		this.medical = medical;
		this.approved = approved;
		this.gender = gender;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int traineeID) {
		this.userID = traineeID;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getBirthYear() {
		return birthYear;
	}

	public void setBirthYear(int birthYear) {
		this.birthYear = birthYear;
	}
	
	public int getBirthMonth() {
		return birthMonth;
	}

	public void setBirthMonth(int birthMonth) {
		this.birthMonth = birthMonth;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public String getMedical() {
		return medical;
	}

	public void setMedical(String medical) {
		this.medical = medical;
	}

	public boolean isApproved() {
		return approved;
	}

	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	

	@Override
	public String toString() {
		return "Trainee [userID=" + userID + ", email=" + email + ", password=" + password + ", firstName="
				+ firstName + ", lastName=" + lastName + ", phone=" + phone + ", address=" + address + ", weight="
				+ weight + ", height=" + height + ", birthYear=" + birthYear + ", birthMonth=" + birthMonth + ", age="
				+ age + ", photo=" + photo + ", medical=" + medical + ", approved=" + approved + "]";
	}
	
	
	
}
