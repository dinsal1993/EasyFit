package Entities;

public class WeeklyReportsTableRow {
	
	private int traineeID;
	private String name;
	private int year;
	private int month;
	private int week;
	private String status;
	
	public WeeklyReportsTableRow(int traineeID, String name, int year, int month, int week, String status) {
		super();
		this.traineeID = traineeID;
		this.name = name;
		this.year = year;
		this.month = month;
		this.week = week;
		this.status = status;
	}

	public int getTraineeID() {
		return traineeID;
	}

	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getWeek() {
		return week;
	}

	public void setWeek(int week) {
		this.week = week;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "WeeklyReportsTableRow [traineeID=" + traineeID + ", name=" + name + ", year=" + year + ", month="
				+ month + ", week=" + week + ", status=" + status + "]";
	}

}
