// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

package client;

import ocsf.client.*;
import sql.EncryptionUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.Map;

import Entities.Exercise;
import Entities.Feedback;
import Entities.Message;
import Entities.Person;
import Entities.Request;
import Entities.Session;
import Entities.Trainer;
import Entities.TrainerTraineeTableRow;
import Entities.WeeklyReport;
import client.gui.controllers.AbstractController;
import client.gui.controllers.AddNewTrainerController;
import client.gui.controllers.CreateTrainingPlanController;
import client.gui.controllers.LoginController;
import client.gui.controllers.ManagerHandlingTraineeRequestController;
import client.gui.controllers.ManagerManagingTrainers;
import client.gui.controllers.ManagerRequestMainController;
import client.gui.controllers.ManagerTraineesController;
import client.gui.controllers.SignUpController;
import client.gui.controllers.TraineeRequestController;
import client.gui.controllers.TrainerFeedbackController;
import client.gui.controllers.TrainerTraineeController;
import client.gui.controllers.TrainerWeeklyReport2Controller;
import client.gui.controllers.TrainerWeeklyReportsMainController;
import client.gui.controllers.ViewTrainingPlanController;
import client.gui.controllers.WeeklyReportsController;

/**
 * This class overrides some of the methods defined in the abstract
 * superclass in order to give more functionality to the client.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;
 * @author Fran&ccedil;ois B&eacute;langer
 * @version July 2000
 */
public class ChatClient extends AbstractClient
{
  //Instance variables **********************************************
  public int globalUserID = -1;
  /**
   * The interface type variable.  It allows the implementation of 
   * the display method in the client.
   */
  ChatIF clientUI; 
  public static boolean waitingForResponse = false;

  
  //Constructors ****************************************************
  
  /**
   * Constructs an instance of the chat client.
   *
   * @param host The server to connect to.
   * @param port The port number to connect on.
   * @param clientUI The interface type variable.
   */
  
  public ChatClient(String host, int port) 
    throws IOException 
  {
    super(host, port); //Call the superclass constructor
    openConnection();
  }

  
  //Instance methods ************************************************
    
  /**
   * This method handles all data that comes in from the server.
   *
   * @param msg The message from the server.
   */
  public void handleMessageFromServer(Object msg) 
  {
	  System.out.println("got message from server");
	  waitingForResponse = false;
	  Message message = (Message) msg;
	  switch (message.getMessageType()) {
	  case login:
		  String msgString = (String) message.getMessageData();
		  if(!msgString.equals("No such user") && !msgString.equals("Already connected") && !msgString.equals("Invalid password") && !msgString.equals("Invalid email")) {
			  String[] info = ((String) message.getMessageData()).split("!");
			  ClientController.client.globalUserID = Integer.parseInt(info[0]);
			  LoginController.role = info[1];
		  }else
			  LoginController.errorMsg = (String) message.getMessageData();
	  break;
	  
	  case logout: 
		  AbstractController.returnMsg = (String) message.getMessageData();
	  break;
	  
	  case createTrainee:
		  SignUpController.createStatus = (String) message.getMessageData();
		  break;
		  
	  case getDecryptionKey:
		  //give the trainer the key so he can decrypty the medical
		  EncryptionUtils.setKey((String) message.getMessageData());
		  break;
		  
	  case fetchTrainees:
		  Map<Integer, String> traineeMap = (Map<Integer, String>) ((ArrayList)message.getMessageData()).get(0);
		  String where = (String) ((ArrayList)message.getMessageData()).get(1);
		  if(where.equals("createPlan"))
			  CreateTrainingPlanController.traineeMap = traineeMap;
		  else if( where.equals("reports"))
			  TrainerWeeklyReportsMainController.names = traineeMap;
		  else
			  ManagerManagingTrainers.traineeMap = traineeMap;
		  break;
		  
	  case fetchExercises:
		  @SuppressWarnings("unchecked") 
		  Map<String, Exercise> exerciseMap = (Map<String, Exercise>) ((ArrayList)message.getMessageData()).get(0);
		  String scene = (String) ((ArrayList)message.getMessageData()).get(1);
		  if (scene.equals("create"))
			  CreateTrainingPlanController.exerciseMap = exerciseMap;
		  else
			  ViewTrainingPlanController.exerciseMap = exerciseMap;
		  break;
		  
	  case addProgram:
		  CreateTrainingPlanController.addProgramStatus = (String) message.getMessageData();
		  break;
	  case deleteProgram:
		  System.out.println((String) message.getMessageData());
		  break;
	  case getProgram:
		  String scene2 = (String)((ArrayList)message.getMessageData()).get(1);
		  if(scene2.equals("view"))
			  ViewTrainingPlanController.sessions = (Map<String, Session>)((ArrayList) message.getMessageData()).get(0);
		  else if(scene2.equals("weekly"))
			  WeeklyReportsController.sessions = (Map<String, Session>)((ArrayList) message.getMessageData()).get(0);
		  else
			  CreateTrainingPlanController.sessions = (Map<String, Session>)((ArrayList) message.getMessageData()).get(0);
		  break;
	  case getName:
		  String scene3 = (String)((ArrayList)message.getMessageData()).get(1);
		  if(scene3.equals("request")) {
			  TraineeRequestController.name = (String)((ArrayList) message.getMessageData()).get(0);
			  System.out.println("In chatclient, request");
		  }
		  else if(scene3.equals("weekly")) {
			  WeeklyReportsController.name = (String)((ArrayList) message.getMessageData()).get(0);
			  System.out.println("In chatclient, weekly");
		  }
		  else if(scene3.equals("report2")) {
			  TrainerWeeklyReport2Controller.traineeName = (String)((ArrayList) message.getMessageData()).get(0);
			  System.out.println("In chatclient, report2");
		  }
		  else {
			  System.out.println("In chatclient, handlingRequestController");
			  ManagerHandlingTraineeRequestController.names.add((String)((ArrayList) message.getMessageData()).get(0));
		  }
		  break;
	  case getTraineeFeedbacks:
		  ArrayList<Feedback> arr = (ArrayList<Feedback>) message.getMessageData();
		  TrainerFeedbackController.traineeFeedbacks = arr;
		  break;
	  case addRequest:
		  TraineeRequestController.sendStatus = (String) message.getMessageData();
		  break;
	  case getTraineeReports:
		  ArrayList<WeeklyReport> reports = (ArrayList<WeeklyReport>) message.getMessageData();
		  System.out.println(reports);
		  TrainerWeeklyReportsMainController.reports = reports;
		  break;
	  case getTrainerID:
		  String scene4 = (String)((ArrayList)message.getMessageData()).get(1);
		  if(scene4.equals("manager"))
			  ManagerRequestMainController.trainerID = (int)((ArrayList)message.getMessageData()).get(0);
		  else
			  WeeklyReportsController.trainerID = (int)((ArrayList)message.getMessageData()).get(0);
		  break;
	  case sendFeedback:
		  TrainerWeeklyReport2Controller.status = (String) message.getMessageData();
		  break;
	  case getTraineesRowData:
		  ArrayList<TrainerTraineeTableRow> tableRowData = (ArrayList<TrainerTraineeTableRow>)message.getMessageData();
		  TrainerTraineeController.traineesList = tableRowData;
		  break;
	  case getTraineesFullData:
		  SignUpController.arrForEdit = (ArrayList) message.getMessageData();
		  break;
	  case getAllRequest:
		  ManagerRequestMainController.requests = (ArrayList<Request>) message.getMessageData(); 
		  break;
	  case getRequest:
		  Request r = (Request)((ArrayList) message.getMessageData()).get(0);
		  String place = (String)((ArrayList) message.getMessageData()).get(1);
		  if(place.equals("handling"))
			  ManagerHandlingTraineeRequestController.req = r;
		  else
			  SignUpController.request = r;
		  break;
	  case getTrainersByTarget:
		  String place1 = (String)((ArrayList) message.getMessageData()).get(1);
		  ArrayList<Trainer> arr1 = ( ArrayList<Trainer>) ((ArrayList) message.getMessageData()).get(0);
		  if(place1.equals("handling"))
			  ManagerHandlingTraineeRequestController.trainers = (ArrayList<Trainer>) ((ArrayList)message.getMessageData()).get(0);
		  else
			  SignUpController.trainers = (ArrayList<Trainer>) ((ArrayList)message.getMessageData()).get(0);
		  break;
	  case getTrainersByTrainer:
		  ManagerHandlingTraineeRequestController.trainers = (ArrayList<Trainer>) message.getMessageData();
		  break;
	  case confirmRequestTarget:
		  ManagerHandlingTraineeRequestController.result = (String) message.getMessageData();
		  break;
	  case confirmRequestTrainer:
		  ManagerHandlingTraineeRequestController.result = (String) message.getMessageData();
		  break;
	  case confirmRequestSignUp:
		  SignUpController.requestReturn = (String) message.getMessageData();
		  break;
	  case getSpecialtyList:
		  System.out.println("in client, list: " + (Map<String, Integer>) message.getMessageData());
		  AddNewTrainerController.specialtyMap = (Map<String, Integer>) message.getMessageData();
		  break;
	  case addNewTrainer:
		  AddNewTrainerController.status = (String) message.getMessageData();
		  break;
	  case getTrainers:
		  System.out.println("client: trainers: " +(Map<String, Integer>)message.getMessageData() );
		  ManagerManagingTrainers.trainers = (Map<String, Integer>)message.getMessageData();
		  break;
	  case removeTraineeFromTrainer:
		  ManagerManagingTrainers.status = (String) message.getMessageData();
		  break;
	  case addTraineeToTrainer:
		  ManagerManagingTrainers.status = (String) message.getMessageData();
		  break;
	  case deleteUser:
		  ManagerTraineesController.status = (String) message.getMessageData();
		  break;
	  }
	  
  }

  /**
   * This method handles all data coming from the UI            
   *
   * @param message The message from the UI.    
   */
  public void handleMessageFromClientUI(Object message)  
  {
    try
    {
    	waitingForResponse = true;
    	sendToServer(message);
    	while (waitingForResponse) {
			try {
				System.out.println("sleep");
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
    }
    catch(IOException e)
    {
      quit();
    }
  }
  
  /**
   * This method terminates the client.
   */
  public void quit()
  {
    try
    {
    	System.out.println("client terminates");
      closeConnection();
    }
    catch(IOException e) {}
    System.exit(0);
  }
}
//End of ChatClient class
