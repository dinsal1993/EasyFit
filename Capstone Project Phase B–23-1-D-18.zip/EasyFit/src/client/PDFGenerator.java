package client;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.font.PDMMType1Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import Entities.TrainingPlanTableRow;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class PDFGenerator {
	public static void generatePDF(TableView<TrainingPlanTableRow> tableView, String filePath) {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);

            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            float margin = 50;
            float yStart = page.getMediaBox().getHeight() - margin;
            float tableWidth = page.getMediaBox().getWidth() - 2 * margin;
            float yPosition = yStart;
            float bottomMargin = 70;
            float tableHeight = 550;

            float yStartNewPage = page.getMediaBox().getHeight() - margin;
            float yPositionNewPage = yStartNewPage;

            float[] columnWidths = { 100, 100, 100, 100 }; // Adjust the widths as per your table columns

            // Write headers
            yPosition = drawTableHeader(contentStream, yStart, tableWidth, yPosition, margin, columnWidths);

            // Write table rows
            yPosition = drawTableContent(contentStream, yStart, tableWidth, yPosition, margin, columnWidths, tableView);

            // Close the content stream
            contentStream.close();

            // Save the document
            document.save(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//END method generatePDF
	
	private static float drawTableHeader(PDPageContentStream contentStream, float y, float tableWidth,
            float yPosition, float margin, float[] columnWidths) throws IOException {
        float currentY = y;
        float rowHeight = 20;
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
        String[] columns = new String[4];
        columns[0] = "Session";
        columns[1] = "Exercise";
        columns[2] = "Sets";
        columns[3] = "Reps";
        
        for (int i = 0; i < columnWidths.length; i++) {
            float x = margin + (i * tableWidth / columnWidths.length);
            contentStream.beginText();
            contentStream.moveTextPositionByAmount(x, currentY);
            contentStream.drawString(columns[i]);
            contentStream.endText();
        }

        yPosition -= rowHeight;
        return yPosition;
    }//END method drawTableHeader
	
	@SuppressWarnings("deprecation")
	private static float drawTableContent(PDPageContentStream contentStream, float y, float tableWidth,
            float yPosition, float margin, float[] columnWidths, TableView<TrainingPlanTableRow> tableView)
            throws IOException {
        float currentY = yPosition;
        float rowHeight = 20;
        contentStream.setFont(PDType1Font.HELVETICA, 12);

        for (TrainingPlanTableRow row : tableView.getItems()) {
            TableColumn<TrainingPlanTableRow, String> sessionColumn = (TableColumn<TrainingPlanTableRow, String>)tableView.getColumns().get(0);
            TableColumn<TrainingPlanTableRow, String> exerciseColumn = (TableColumn<TrainingPlanTableRow, String>)tableView.getColumns().get(1);
            TableColumn<TrainingPlanTableRow, String> setsColumn = (TableColumn<TrainingPlanTableRow, String>)tableView.getColumns().get(2);
            TableColumn<TrainingPlanTableRow, String> repsColumn = (TableColumn<TrainingPlanTableRow, String>)tableView.getColumns().get(3);

            // Draw each cell in the row
            float x = margin;
            contentStream.beginText();
            contentStream.moveTextPositionByAmount(x, currentY);
            contentStream.drawString(sessionColumn.getCellData(row));
            contentStream.moveTextPositionByAmount(columnWidths[0], 0);
            contentStream.drawString(exerciseColumn.getCellData(row));
            contentStream.moveTextPositionByAmount(columnWidths[1], 0);
            contentStream.drawString(setsColumn.getCellData(row));
            contentStream.moveTextPositionByAmount(columnWidths[2], 0);
            contentStream.drawString(repsColumn.getCellData(row));
            contentStream.endText();

            currentY -= rowHeight;
        }

        return currentY;
    }
}