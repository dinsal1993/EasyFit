package client.gui.controllers;

import java.io.IOException;
import java.util.ArrayList;

import Entities.Goal;
import Entities.Message;
import Entities.MessageType;
import Entities.Request;
import client.ClientController;
import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class TraineeRequestController extends AbstractController{

	@FXML
    private Text txtTrainingPlan;

    @FXML
    private Text txtWeeklyReports;

    @FXML
    private Text txtTrainerFeedback;

    @FXML
    private Button btnSend;

    @FXML
    private TextArea txtDetails;

    @FXML
    private Slider sliderDuration;

    @FXML
    private Slider sliderActivity;

    @FXML
    private TextField txtOther;
    
    @FXML
    private ChoiceBox<Goal> dropTarget;

    @FXML
    private ChoiceBox<Integer> dropWeekly;
    
    @FXML
    private ChoiceBox<String> dropChange;
    
    @FXML
    private Text lblTarget;

    @FXML
    private Text lblOther;

    @FXML
    private Text lblDuration;

    @FXML
    private Text lblSessions;

    @FXML
    private Text lblDaily;
    
    @FXML
    private TextField txtName;

    @FXML
    private TextField txtID;
    
    public static String name = "";
    public static String sendStatus = "";
    @FXML
    public void initialize() {
    	setTargetVisible(false);
    	setTargetDisable(true);
    	
    	ArrayList info = new ArrayList();
    	info.add(ClientController.client.globalUserID);
    	info.add("request");
    	ClientUI.chat.accept(new Message(MessageType.getName, info));
    	
    	System.out.println("ID is: " + ClientController.client.globalUserID);
    	//txtID.setDisable(false);
    	txtID.setText(String.valueOf(ClientController.client.globalUserID));
    	txtName.setText(name);
    	
    	fillChange();
    	fillTarget();
    	fillWeeklySessions();
    	
    	dropChange.setOnAction(event -> {
    		String change = dropChange.getValue();
    		txtOther.clear();
    		if(change.equals("Trainer")) {
    			setTargetDisable(true);
    			setTargetVisible(false);
    		}else {
    			//change target
    			setTargetVisible(true);
    			setTargetDisable(false);
    		}
    	});
    	
    	current.setOnCloseRequest(event -> {
    		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
    		System.exit(0);
    	});
    }
    
    private void setTargetVisible(boolean b) {
		lblTarget.setVisible(b);
		lblOther.setVisible(b);
		lblDuration.setVisible(b);
		lblSessions.setVisible(b);
		lblDaily.setVisible(b);
		dropTarget.setVisible(b);
		txtOther.setVisible(b);
		sliderActivity.setVisible(b);
		sliderDuration.setVisible(b);
		dropWeekly.setVisible(b);
	}

	private void setTargetDisable(boolean b) {
		lblTarget.setDisable(b);
		lblOther.setDisable(b);
		lblDuration.setDisable(b);
		lblSessions.setDisable(b);
		lblDaily.setDisable(b);
		dropTarget.setDisable(b);
		txtOther.setDisable(b);
		sliderActivity.setDisable(b);
		sliderDuration.setDisable(b);
		dropWeekly.setDisable(b);
	}

	private void fillChange() {
    	ObservableList<String> change = FXCollections.observableArrayList("Trainer", "Target");
		dropChange.setItems(change);
	}

	private void fillTarget() {
		ObservableList<Goal> goalList = FXCollections.observableArrayList(Goal.values());
		dropTarget.setItems(goalList);
	}
    
    private void fillWeeklySessions() {
		ObservableList<Integer> weeklyList = FXCollections.observableArrayList(1,2,3,4,5,6,7);
		dropWeekly.setItems(weeklyList);
		
	}

    @FXML
    void clickTrainerFeedback(MouseEvent event) throws IOException {
    	start(event, "trainerFeedback", "Trainer Feedbacks");
    }

    @FXML
    void clickTrainingPlan(MouseEvent event) throws IOException {
    	start(event, "viewTrainingPlan", "My Training Plan");
    }

    @FXML
    void clickWeeklyReports(MouseEvent event) throws IOException {
    	start(event, "weeklyReports", "My Weekly Reports");
    }
    
    @FXML
    void send(ActionEvent event) {
    	if (validateInput()) {
    		String type = dropChange.getValue();
    		Request r = null;
    		if(type.equals("Trainer")) {
    			String details = txtDetails.getText();
    			r = new Request(ClientController.client.globalUserID, type, details, "",
    					0, 0, 0);
    		}else { // Change Target
    			String details = txtDetails.getText();
    			String target = "";
    			if(txtOther.getText().isEmpty())
    				target = dropTarget.getValue().name();
    			else
    				target = txtOther.getText();
    			int weeklySessions = dropWeekly.getValue();
    			int trainingDuration = (int)sliderDuration.getValue();
        		int dailyActivity = (int)sliderActivity.getValue();
        		r = new Request(ClientController.client.globalUserID, type, details, target,
        				weeklySessions, trainingDuration, dailyActivity);	
    		}
    		ClientUI.chat.accept(new Message(MessageType.addRequest, r));
    		showAlert(AlertType.CONFIRMATION, "Send Request", "Request", sendStatus);
    	}	
    }
    
    private boolean validateInput() {
        String change = dropChange.getValue();
        if (change == null) {
            showAlert(AlertType.ERROR, "Error", "Missing Change Option", "Please select a change option.");
            return false;
        }

        if (change.equals("Trainer")) {
            if (txtDetails.getText().isEmpty()) {
                showAlert(AlertType.ERROR, "Error", "Missing Details", "Please provide details for the trainer change request.");
                return false;
            }
        } else { // Change Target
            if (dropTarget.getValue() == null && txtOther.getText().isEmpty()) {
                showAlert(AlertType.ERROR, "Error", "Missing Target", "Please select a target or provide other text for the target request.");
                return false;
            }
            
            if (dropWeekly.getValue() == null) {
                showAlert(AlertType.ERROR, "Error", "Missing Weekly Sessions", "Please select the number of weekly sessions.");
                return false;
            }
            
            if(dropTarget.getValue() != null && !txtOther.getText().isEmpty()) {
            	showAlert(AlertType.ERROR, "Error", "Multiple targets", "Please either select a target or provide other text for the target request, but not both");
                return false;
            }
        }

        

        return true;
    }

}
