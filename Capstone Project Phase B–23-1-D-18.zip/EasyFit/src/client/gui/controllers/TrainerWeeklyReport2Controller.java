package client.gui.controllers;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Set;

import javax.imageio.ImageIO;

import Entities.Feedback;
import Entities.Message;
import Entities.MessageType;
import Entities.WeeklyReport;
import client.ClientController;
import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class TrainerWeeklyReport2Controller extends AbstractController {

    @FXML
    private Text txtPhoto;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtWeekly;

    @FXML
    private TextField txtWeight;

    @FXML
    private TextArea txtNotes;

    @FXML
    private TextField txtYear;

    @FXML
    private TextField txtMonth;

    @FXML
    private TextField txtWeek;

    @FXML
    private TextArea txtFeedback;

    @FXML
    private TextArea txtExerciseNotes;

    @FXML
    private Button btnSend;

    @FXML
    private ListView<String> lstExercises;

    @FXML
    private TextArea txtTraineeNotes;
    
    @FXML
    private ImageView imgPhoto;
    
    @FXML
    private Button btnPhoto;
    
    @FXML
    private Text txtCreate;

    @FXML
    private Text txtReports;

    @FXML
    private Text txtTrainees;
    
    public static String traineeName;
    public static ObservableList<String> exerciseNameList = FXCollections.observableArrayList();
    public static WeeklyReport report;
    public static String status;
    
    

    @FXML
    void clickPhoto(ActionEvent event) {	
    	byte[] photoBytes = report.getPhoto();
        if (photoBytes != null) {
            InputStream inputStream = new ByteArrayInputStream(photoBytes);
            Image image = new Image(inputStream);
            //imgPhoto.setImage(image);

            Stage tempStage = new Stage();
            tempStage.initStyle(StageStyle.DECORATED);

            ImageView imageView = new ImageView(image); // Create a new ImageView
            

            Pane container = new Pane();
            container.getChildren().add(imageView); // Add the ImageView to the container

            Scene scene = new Scene(container);
            
			/*
			 * tempStage.setWidth(800); // Set the width of the stage
			 * tempStage.setHeight(600); // Set the height of the stage
			 * 
			 * imageView.setPreserveRatio(true);
			 * imageView.fitWidthProperty().bind(tempStage.widthProperty());
			 * imageView.fitHeightProperty().bind(tempStage.heightProperty());
			 */
            
            imageView.setPreserveRatio(true);
            imageView.setFitWidth(800);
            imageView.setFitHeight(600);
            imageView.setSmooth(true); // Optional: Enable image smoothing for better quality
            
            tempStage.setScene(scene);
            tempStage.show();
        }
    }

    @FXML
    void send(ActionEvent event) {
    	String feedback = txtFeedback.getText().trim();
        String exerciseNotes = txtExerciseNotes.getText().trim();
        if(valid(feedback, exerciseNotes)) {
        	int traineeID = Integer.parseInt(txtID.getText().trim());
        	int year = Integer.parseInt(txtYear.getText().trim());
            int month = Integer.parseInt(txtMonth.getText().trim());
            int week = Integer.parseInt(txtWeek.getText().trim());
        	Feedback fb = new Feedback(traineeID, exerciseNotes, feedback, year, month, week);
        	ClientUI.chat.accept(new Message(MessageType.sendFeedback, fb));
        	showAlert(AlertType.CONFIRMATION, "Send Feedback", "Send Feedback", status);
        }
    }

	private boolean valid(String feedback, String exerciseNotes) {
		if (feedback.isEmpty()) {
	        showAlert(AlertType.ERROR, "Empty Field", "Empty Field Error", "Please fill feedback");
	        return false;
	    }
		
		if (!lstExercises.getItems().isEmpty()) {
	        if (exerciseNotes.isEmpty()) {
	        	showAlert(AlertType.ERROR, "Empty Field", "Empty Field Error", "Please fill notes for exercises");
		        return false;
	        }
	    }
		return true;
	}

	public void start(WeeklyReport wr) {
		//Insert report details
		report = wr;
		txtYear.setText(String.valueOf(wr.getYear()));
		txtMonth.setText(String.valueOf(wr.getMonth()));
		txtWeek.setText(String.valueOf(wr.getWeek()));
		
		ArrayList info = new ArrayList();
		info.add(wr.getTraineeID());
		info.add("report2");
		ClientUI.chat.accept(new Message(MessageType.getName, info));
		
		txtName.setText(traineeName);
		txtID.setText(String.valueOf(wr.getTraineeID()));
		txtWeekly.setText(String.valueOf(wr.getSessionsPerformed()));
		txtWeight.setText(String.valueOf(wr.getWeight()));
		txtNotes.setText(wr.getNotes());
		
		Set<String> exercises = wr.getExerciseNotes().keySet();
		exerciseNameList.addAll(exercises);
		lstExercises.setItems(exerciseNameList);
		
		lstExercises.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                // Retrieve exercise note based on selected exercise name
                String exerciseNote = wr.getExerciseNotes().get(newValue);

                // Set exercise note on the text field
                txtTraineeNotes.setText(exerciseNote);
            }
        });	
	}
	
	@FXML
    void clickReports(MouseEvent event) throws IOException {
		start(event, "trainerWeeklyReportsMain", "Weekly Reports");
    }
	
    @FXML
    void clickCreate(MouseEvent event) throws IOException {
		start(event, "createTrainingPlan", "Create New Training Plan");
    }

    @FXML
    void clickTrainees(MouseEvent event) throws IOException {
    	start(event, "trainerTrainee", "My Trainees");
    }

}
