package client.gui.controllers;

import java.io.IOException;

import Entities.Message;
import Entities.MessageType;
import Entities.Request;
import Entities.WeeklyReport;
import client.ClientController;
import client.ClientUI;
import client.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public abstract class AbstractController {
	
	public static String returnMsg;
	public static Stage current;
	
	/*
	 * public void start(ActionEvent event, String fxmlName, String title) throws
	 * IOException { ((Node) event.getSource()).getScene().getWindow().hide(); Stage
	 * primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	 * //FXMLLoader load = new FXMLLoader(getClass().getResource("/fxml/" + fxmlName
	 * + ".fxml")); FXMLLoader loader = new
	 * FXMLLoader(Main.class.getResource("gui/fxml/" + fxmlName + ".fxml"));
	 * 
	 * Parent root = loader.load(); //AbstractController aFrame =
	 * loader.getController(); Scene scene = new Scene(root);
	 * 
	 * primaryStage.setTitle("EasyFit" + " " + title); primaryStage.setScene(scene);
	 * primaryStage.setResizable(false); primaryStage.show(); current =
	 * primaryStage; }
	 */
	
	public void start(ActionEvent event, String fxmlName, String title) throws IOException {
	    ((Node) event.getSource()).getScene().getWindow().hide();
	    Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    FXMLLoader loader = new FXMLLoader(Main.class.getResource("gui/fxml/" + fxmlName + ".fxml"));
	    Parent root = loader.load();
	    Scene scene = new Scene(root);
	    
	    primaryStage.setTitle("EasyFit" + " " + title);
	    primaryStage.setScene(scene);
	    primaryStage.setResizable(false);
	    current = primaryStage; // Set the current stage before showing it
	    current.show();
	}
	
	//Special start for editing training plan
	public void start2(ActionEvent event, String fxmlName, String title) throws IOException {
	    ((Node) event.getSource()).getScene().getWindow().hide();
	    Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    FXMLLoader loader = new FXMLLoader(Main.class.getResource("gui/fxml/" + fxmlName + ".fxml"));
	    Parent root = loader.load();
	    Scene scene = new Scene(root);
	    
	    primaryStage.setTitle("EasyFit" + " " + title);
	    primaryStage.setScene(scene);
	    primaryStage.setResizable(false);
	    current = primaryStage; // Set the current stage before showing it
	    current.show();
	    ((CreateTrainingPlanController) loader.getController()).checkEdit();
	}
	
	//Special start for viewing trainee details
		public void start3(ActionEvent event, String fxmlName, String title) throws IOException {
		    //((Node) event.getSource()).getScene().getWindow().hide();
		    Stage primaryStage = new Stage();
		    FXMLLoader loader = new FXMLLoader(Main.class.getResource("gui/fxml/" + fxmlName + ".fxml"));
		    Parent root = loader.load();
		    Scene scene = new Scene(root);
		    
		    primaryStage.setTitle("EasyFit" + " " + title);
		    System.out.println("title: " + primaryStage.getTitle());
		    primaryStage.setScene(scene);
		    primaryStage.setResizable(false);
		    current = primaryStage; // Set the current stage before showing it
		    current.show();
		    try {
				((SignUpController) loader.getController()).checkEdit();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	public void start(MouseEvent event, String fxmlName, String title) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		FXMLLoader load = new FXMLLoader(Main.class.getResource("gui/fxml/" + fxmlName + ".fxml"));
		Parent root = load.load();
		//AbstractController aFrame = load.getController();
		Scene scene = new Scene(root);
		primaryStage.setTitle("EasyFit" + " " + title);
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.show();
		current = primaryStage;

	}
	
	//Special Start method for weeklyReports
	public void start(ActionEvent event, String fxmlName, String title, WeeklyReport wr) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		//FXMLLoader load = new FXMLLoader(getClass().getResource("/fxml/" + fxmlName + ".fxml"));
		FXMLLoader loader = new FXMLLoader(Main.class.getResource("gui/fxml/" + fxmlName + ".fxml"));

		Parent root = loader.load();
		
		TrainerWeeklyReport2Controller wr2c = loader.getController();
		wr2c.start(wr);
		//loader.setController(wr2c);
		
		//AbstractController aFrame = load.getController();
		Scene scene = new Scene(root);
		primaryStage.setTitle("EasyFit" + " " + title);
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.show();
		current = primaryStage;
	}
	
	//Special Start method for ManagerHandlingTraineeRequest
		public void start(ActionEvent event, String fxmlName, String title, int requestID, int traineeID, int trainerID) throws IOException {
			((Node) event.getSource()).getScene().getWindow().hide();
			Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			//FXMLLoader load = new FXMLLoader(getClass().getResource("/fxml/" + fxmlName + ".fxml"));
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("gui/fxml/" + fxmlName + ".fxml"));

			Parent root = loader.load();
			
			ManagerHandlingTraineeRequestController controller = loader.getController();
			controller.start(requestID, traineeID, trainerID);
			//loader.setController(wr2c);
			
			//AbstractController aFrame = load.getController();
			Scene scene = new Scene(root);
			primaryStage.setTitle("EasyFit" + " " + title);
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			current = primaryStage;
		}
		
		//Special Start method for ManagerManagingTrainees
		public void startManager(MouseEvent event, String fxmlName, String title) throws IOException {
			((Node) event.getSource()).getScene().getWindow().hide();
			Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			//FXMLLoader load = new FXMLLoader(getClass().getResource("/fxml/" + fxmlName + ".fxml"));
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("gui/fxml/" + fxmlName + ".fxml"));

			Parent root = loader.load();
			
			ManagerManagingTrainers m = loader.getController();
			m.start();
			//loader.setController(wr2c);
			
			//AbstractController aFrame = load.getController();
			Scene scene = new Scene(root);
			primaryStage.setTitle("EasyFit" + " " + title);
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			current = primaryStage;
		}
	
	//exit the application
	public void exitApp() {
		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
		System.exit(0);
	}
	
	//logout the user and go back to login screen
	public void logout(ActionEvent event, int userID) throws IOException {
		Alert a;
		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
		if(returnMsg.equals("OK"))
			start(event, "login", "Login");
		else {
			a = new Alert(AlertType.ERROR, returnMsg);
			a.show();
		}
	}
	
	public void showAlert(AlertType alertType, String title, String headerText, String contentText) {
	    Alert alert = new Alert(alertType);
	    alert.setTitle(title);
	    alert.setHeaderText(headerText);
	    alert.setContentText(contentText);
	    alert.showAndWait();
	}

}
