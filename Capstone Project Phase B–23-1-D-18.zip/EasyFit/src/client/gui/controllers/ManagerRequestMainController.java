package client.gui.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;

import Entities.ManagerRequestTableRow;
import Entities.Message;
import Entities.MessageType;
import Entities.Request;
import Entities.TrainingPlanTableRow;
import Entities.WeeklyReport;
import client.ClientController;
import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class ManagerRequestMainController extends AbstractController {

	@FXML
    private Text txtAddTrainer;

    @FXML
    private Text txtTrainers;

    @FXML
    private Text txtTrainees;

    @FXML
    private TableView<ManagerRequestTableRow> tblRequests;

    @FXML
    private Button btnOpen;
    
    private static ObservableList<ManagerRequestTableRow> data;
    public static ArrayList<Request> requests;
    public static int trainerID;
    
    @FXML
    public void initialize() {
    	current.setOnCloseRequest(event -> {
    		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
    		System.exit(0);
    	});
    	
    	defineTable();
    	fillTable();
    }

    private void fillTable() {
    	ClientUI.chat.accept(new Message(MessageType.getAllRequest, null));
    	requests.sort(Comparator.comparing(Request::getTraineeID,
    			Comparator.naturalOrder()).thenComparing(Request::getRequestID, Comparator.naturalOrder())
    			);
    	
    	System.out.println("requestList: " + requests);
    	
    	
    	for(Request r : requests) {
    		ArrayList info = new ArrayList();
    		info.add(r.getTraineeID());
    		info.add("manager");
    		ClientUI.chat.accept(new Message(MessageType.getTrainerID, info));
    		tblRequests.getItems().add(new ManagerRequestTableRow(r.getRequestID(), r.getTraineeID(), trainerID, r.getType(), r.getStatus()));
    	}
	}

	@SuppressWarnings("unchecked")
	private void defineTable() {
		// Define table columns
		TableColumn<ManagerRequestTableRow, Integer> requestColumn = new TableColumn<>("Request ID");
		requestColumn.setCellValueFactory(new PropertyValueFactory<>("requestID"));
		
	    TableColumn<ManagerRequestTableRow, Integer> idColumn = new TableColumn<>("Trainee ID");
	    idColumn.setCellValueFactory(new PropertyValueFactory<>("traineeID"));

	    TableColumn<ManagerRequestTableRow, Integer> trainerColumn = new TableColumn<>("Trainer ID");
	    trainerColumn.setCellValueFactory(new PropertyValueFactory<>("trainer"));

	    TableColumn<ManagerRequestTableRow, String> typeColumn = new TableColumn<>("type");
	    typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));

	    TableColumn<ManagerRequestTableRow, String> statusColumn = new TableColumn<>("Status");
	    statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

	    // Add the columns to the TableView
	    tblRequests.getColumns().addAll(requestColumn, idColumn, trainerColumn, typeColumn,
	    		statusColumn);
	    tblRequests.getItems().clear();
	    data = FXCollections.observableArrayList();
	    // Bind the data to the TableView
	    tblRequests.setItems(data);
		
	}

	@FXML
    void clickAddNewTrainer(MouseEvent event) throws IOException {
    	start(event, "addNewTrainer", "Add New Trainer");
    }

    @FXML
    void clickTrainees(MouseEvent event) throws IOException {
    	start(event, "managerTrainees", "Trainees");
    }

    @FXML
    void clickTrainers(MouseEvent event) throws IOException {
    	startManager(event, "managerManagingTrainers", "Manage Trainers");
    }
    
    @FXML
    void open(ActionEvent event) throws IOException {
    	ManagerRequestTableRow selectedRow = tblRequests.getSelectionModel().getSelectedItem();
        if (selectedRow != null) {
            String selectedType = selectedRow.getType();
            if (selectedType.equals("Target") || selectedType.equals("Trainer")) {
                start(event, "managerHandlingTraineeRequest", "Handling Request", selectedRow.getRequestID(), selectedRow.getTraineeID(), selectedRow.getTrainer());
            } else {
            	start3(event, "signUp", "View Trainee Details!" + selectedRow.getTraineeID() + "!request!" + selectedRow.getRequestID()  );
            }
        }
    }

}
