package client.gui.controllers;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import Entities.Exercise;
import Entities.Message;
import Entities.MessageType;
import Entities.Program;
import Entities.Session;
import Entities.TrainingPlanTableRow;
import client.ClientController;
import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ChoiceBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import sql.DBConnect;


public class CreateTrainingPlanController extends AbstractController {
	
	// Map to store trainee IDs and names
    public static Map<Integer, String> traineeMap;
    public static Map<String, ArrayList<Exercise>> sortedExercisesMap = new HashMap<>();
    public static Map<String, Exercise> exerciseMap;

    private static ObservableList<TrainingPlanTableRow> data;
    
    private static Program p;
    public static String addProgramStatus;
    
    public static Map<String, Session> sessions = null;
    
    @FXML
    private ChoiceBox<String> dropTrainee;

    @FXML
    private ChoiceBox<String> dropSession;

    @FXML
    private ChoiceBox<String> dropMuscleGroup;

    @FXML
    private ChoiceBox<String> dropExercise;

    @FXML
    private ChoiceBox<String> dropSets;

    @FXML
    private ChoiceBox<String> dropReps;

    @FXML
    private Label lblDescription;

    @FXML
    private Hyperlink linkYoutube;

    @FXML
    private TableView<TrainingPlanTableRow> tablePlan;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnEdit;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnBack;
    
    @FXML
    private Button btnFinish;
    
    @FXML
    private Text txtTitle;
    
    private static Alert alert;
	

    @FXML
    void add(ActionEvent event) {
    	if(validate()) {
    		//check that exercise not in the table already
        	if (existInTable(dropExercise.getValue(), dropSession.getValue())) {
        		alert = new Alert(AlertType.ERROR, "Exercise already added to plan");
        		alert.showAndWait();
        	}else {
        		TrainingPlanTableRow newRow = new TrainingPlanTableRow(dropSession.getValue(),
        				dropExercise.getValue(), dropSets.getValue(), dropReps.getValue());
        		data.add(newRow);
        	}
    	}
    	
    }
    
    private boolean validate() {
    	if (dropTrainee.getValue() == null) {
            showAlert(AlertType.ERROR, "Validation Error", "Trainee not selected", "Please select a trainee.");
            return false;
        }
        if (dropSession.getValue() == null) {
            showAlert(AlertType.ERROR, "Validation Error", "Session not selected", "Please select a session.");
            return false;
        }
        if (dropExercise.getValue() == null) {
            showAlert(AlertType.ERROR, "Validation Error", "Exercise not selected", "Please select an exercise.");
            return false;
        }
        if (dropSets.getValue() == null) {
            showAlert(AlertType.ERROR, "Validation Error", "Sets not selected", "Please select the number of sets.");
            return false;
        }
        if (dropReps.getValue() == null) {
            showAlert(AlertType.ERROR, "Validation Error", "Reps not selected", "Please select the number of repetitions.");
            return false;
        }
        return true;
	}

    
    
	/*
	 * public static void addPhotoEx(byte[] a, int name) { PreparedStatement stmt;
	 * String sql = "INSERT INTO exercise (photo) VALUES (?) WHERE exercise_ID = ?";
	 * if (DBConnect.conn != null) { try { stmt =
	 * DBConnect.conn.prepareStatement(sql); stmt.setBytes(1, a); stmt.setInt(2,
	 * name); stmt.executeUpdate();
	 * 
	 * 
	 * }catch (SQLException e) { // catch for manager e.printStackTrace(); } } }
	 */
    
	@FXML
    void finish(ActionEvent event) {
		
		/*
		 * if(true) { byte[] fileData; FileChooser fileChooser = new FileChooser();
		 * fileChooser.setTitle("Choose an Image File"); File selectedFile =
		 * fileChooser.showOpenDialog(null); if (selectedFile != null) { try { // Read
		 * the selected file as a byte array int name =
		 * Integer.parseInt(selectedFile.getName().substring(0,
		 * selectedFile.getName().length()-5)); fileData =
		 * Files.readAllBytes(selectedFile.toPath()); addPhotoEx(fileData, name); }
		 * catch (IOException e) { // Handle any IO errors e.printStackTrace(); } }
		 * return; }
		 */
		
    	int traineeID = Integer.parseInt(dropTrainee.getValue().split(",")[0]);
    	
    	//Before adding new program for trainee, delete old program
    	ClientUI.chat.accept(new Message(MessageType.deleteProgram, traineeID));
    	
    	Map<String, Session> sessions = new HashMap<>();
    	sessions.put("A", new Session(traineeID, new ArrayList<Exercise>(), new ArrayList<String>(), new ArrayList<String>(), "A"));
    	sessions.put("B", new Session(traineeID, new ArrayList<Exercise>(), new ArrayList<String>(), new ArrayList<String>(), "B"));
    	sessions.put("C", new Session(traineeID, new ArrayList<Exercise>(), new ArrayList<String>(), new ArrayList<String>(), "C"));
    	sessions.put("D", new Session(traineeID, new ArrayList<Exercise>(), new ArrayList<String>(), new ArrayList<String>(), "D"));
    	sessions.put("E", new Session(traineeID, new ArrayList<Exercise>(), new ArrayList<String>(), new ArrayList<String>(), "E"));
    	sessions.put("F", new Session(traineeID, new ArrayList<Exercise>(), new ArrayList<String>(), new ArrayList<String>(), "F"));
    	
    	for (TrainingPlanTableRow row : data) {
    		String s = row.getSession();
    		Exercise e = exerciseMap.get(row.getExercise());
    		sessions.get(s).getExercises().add(e);
    		sessions.get(s).getSets().add(row.getSets());
    		sessions.get(s).getRepetitions().add(row.getReps());   		
    	}
    	p = new Program(traineeID, new ArrayList<Session>());
    	sessions.forEach((key, value) -> {
			if(value.getExercises().size() > 0)
				p.getSessions().add(value);
		});
    	ClientUI.chat.accept(new Message(MessageType.addProgram, p));
    	alert = new Alert(AlertType.INFORMATION, addProgramStatus);
    	alert.showAndWait();
    }

	@FXML
    void back(ActionEvent event) {
    	
    }

    @FXML
    void delete(ActionEvent event) {
    	// Get the selected row(s)
        ObservableList<TrainingPlanTableRow> selectedRows = tablePlan.getSelectionModel().getSelectedItems();

        // Remove the selected row(s) from the data source
        data.removeAll(selectedRows);

        // Clear the selection
        tablePlan.getSelectionModel().clearSelection();
    }

    @FXML
    void edit(ActionEvent event) {
    	if (btnEdit.getText().equals("Edit")) {
            enableEditing();
            btnEdit.setText("Save");
        } else {     	
            disableEditing();
            btnEdit.setText("Edit");
        }
    }
    
    @FXML
    public void initialize() {
    	//Get list of exercises
    	ClientUI.chat.accept(new Message(MessageType.fetchExercises, "create"));
    	//Sort exercises by Muscle Group
		sortMap();
		
		//Get the trainees of the trainer
        fetchTraineesFromDatabase();
        
        //Fill the choiceboxes
        fillChoiceBox("trainee");
        fillChoiceBox("session");
        fillChoiceBox("muscleGroup");
        fillChoiceBox("sets");
        fillChoiceBox("reps");
        
        defineTable();
        

        //Display exercise details when selecting exercise from list
        dropExercise.setOnAction(event -> {
        	if(dropExercise.getValue() != null)
        	{
        		String value = dropExercise.getValue();
            	
            	lblDescription.setText(exerciseMap.get(value).getDescription());
            	
            	linkYoutube.setOnAction(event2 -> {
            	    String url = exerciseMap.get(value).getVideo();
            	    if (Desktop.isDesktopSupported()) {
            	        Desktop desktop = Desktop.getDesktop();
            	        try {
            	            desktop.browse(new URI(url));
            	        } catch (IOException | URISyntaxException e) {
            	            e.printStackTrace();
            	        }
            	    }
            });
        	}
        	
        });
        
        
        
        current.setOnCloseRequest(event -> {
    		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
    		System.exit(0);
    	});
        
    }

	public void checkEdit() {
		/*
		 * System.out.println("before Edit" + current.getTitle()); Stage currentStage =
		 * (Stage) txtTitle.getScene().getWindow(); String title =
		 * currentStage.getTitle(); System.out.println("contain: " +
		 * current.getTitle().contains("Edit"));
		 */
      //Enter in edit mode
        if(current.getTitle().contains("Edit")) {
        	System.out.println("contain Edit");
        	String[] info = current.getTitle().split("!");
        	current.setTitle(info[0]);
        	txtTitle.setText("Edit Plan");
        	
        	String traineeID = info[1];
        	if(checkExistProgram(traineeID)) {
        		System.out.println("Program exist: " + sessions);
        		dropTrainee.getItems().clear();
        		dropTrainee.getItems().add(traineeID);
        		fillTableForEdit();
        		
        	}else {
        		showAlert(AlertType.ERROR, "Edit Program", "Edit Program", "Trainee has no program yet");
        		current.setTitle("Create new training plan");
        	}
        }
		
	}

	private void fillTableForEdit() {
		tablePlan.getItems().clear();
        // Iterate over the sessions map
        for (Map.Entry<String, Session> entry : sessions.entrySet()) {
            String key = entry.getKey(); 
            Session session = entry.getValue(); 
            
            ArrayList<Exercise> exercises = session.getExercises();
        	ArrayList<String> sets = session.getSets();
        	ArrayList<String> repetitions = session.getRepetitions();
        	for(int i = 0; i < exercises.size(); i++) {
        		data.add(new TrainingPlanTableRow(key, exercises.get(i).getName(), sets.get(i), repetitions.get(i)));
        	}
        }
		
	}

	private boolean checkExistProgram(String traineeID) {
		ArrayList info2 = new ArrayList<>();
    	info2.add(Integer.parseInt(traineeID));
    	info2.add("edit");
		ClientUI.chat.accept(new Message(MessageType.getProgram, info2));
		if(sessions.isEmpty())
			return false;
		return true;
	}

	private void disableEditing() {
		tablePlan.setEditable(false);
		tablePlan.getSelectionModel().setCellSelectionEnabled(false);
		tablePlan.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		tablePlan.getSelectionModel().clearSelection();
		tablePlan.refresh();
		
	}

	private void enableEditing() {
		tablePlan.setEditable(true);
		tablePlan.getSelectionModel().setCellSelectionEnabled(true);
		tablePlan.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		tablePlan.edit(tablePlan.getSelectionModel().getSelectedIndex(), tablePlan.getColumns().get(0));
    }

	@SuppressWarnings("unchecked")
	private void defineTable() {
		// Define table columns
	    TableColumn<TrainingPlanTableRow, String> sessionColumn = new TableColumn<>("session");
	    sessionColumn.setCellValueFactory(new PropertyValueFactory<>("session"));
	    sessionColumn.setCellFactory(ChoiceBoxTableCell.forTableColumn("A", "B", "C", "D",
	    		"E", "F"));
	    sessionColumn.setOnEditCommit(event -> {
	        // Update the corresponding data in the ObservableList
	        TrainingPlanTableRow row = event.getRowValue();
	        row.setSession(event.getNewValue());
	    });

	    TableColumn<TrainingPlanTableRow, String> exerciseColumn = new TableColumn<>("exercise");
	    exerciseColumn.setCellValueFactory(new PropertyValueFactory<>("exercise"));
	    exerciseColumn.setCellFactory(ChoiceBoxTableCell.forTableColumn(
	            FXCollections.observableArrayList(exerciseMap.keySet())
	    ));
	    exerciseColumn.setOnEditCommit(event -> {
	        // Update the corresponding data in the ObservableList
	        TrainingPlanTableRow row = event.getRowValue();
	        row.setExercise(event.getNewValue());
	    });

	    TableColumn<TrainingPlanTableRow, String> setsColumn = new TableColumn<>("sets");
	    setsColumn.setCellValueFactory(new PropertyValueFactory<>("sets"));
	    setsColumn.setCellFactory(ChoiceBoxTableCell.forTableColumn("1", "2", "3", "4", "5"));
	    setsColumn.setOnEditCommit(event -> {
	        // Update the corresponding data in the ObservableList
	        TrainingPlanTableRow row = event.getRowValue();
	        row.setSets(event.getNewValue());
	    });

	    TableColumn<TrainingPlanTableRow, String> repsColumn = new TableColumn<>("reps");
	    repsColumn.setCellValueFactory(new PropertyValueFactory<>("reps"));
	    repsColumn.setCellFactory(ChoiceBoxTableCell.forTableColumn("1-3", "3-5", "8-12", "15-18",
				"To Failure"));
	    repsColumn.setOnEditCommit(event -> {
	        // Update the corresponding data in the ObservableList
	        TrainingPlanTableRow row = event.getRowValue();
	        row.setReps(event.getNewValue());
	    });

	    // Add the columns to the TableView
	    tablePlan.getColumns().addAll(sessionColumn, exerciseColumn, setsColumn, repsColumn);
	    
	    tablePlan.getItems().clear();
	    data = FXCollections.observableArrayList();
	    // Bind the data to the TableView
	    tablePlan.setItems(data);
		
	}

	private void fillChoiceBox(String box) {
		
		switch(box) {
		case "trainee": traineeMap.forEach((key, value) -> 
		dropTrainee.getItems().add(key + "," + value));
		break;
		
		case "session": dropSession.getItems().addAll("A", "B", "C", "D", "E", "F");
		break;
		
		case "muscleGroup":
			dropMuscleGroup.getItems().addAll("Chest", "Shoulders","Arms", "Legs", "Back",
					"Core");
			
			//Set exercises in Exercise choicebox according to muscle group
			dropMuscleGroup.setOnAction(event -> {
	            String selectedMuscleGroup = dropMuscleGroup.getValue();
	            ArrayList<Exercise> exercises = sortedExercisesMap.get(selectedMuscleGroup);
	            dropExercise.getItems().clear(); // Clear existing items
	            if (exercises != null) {
	                for (Exercise exercise : exercises) {
	                    dropExercise.getItems().add(exercise.getName());
	                }
	            }
	        });
			
		break;
		
		case "sets": dropSets.getItems().addAll("1", "2", "3", "4", "5");
		break;
		
		case "reps": dropReps.getItems().addAll("1-3", "3-5", "8-12", "15-18",
				"To Failure");
		break;
		}
		
	}

	private void sortMap() {		
		sortedExercisesMap = new HashMap<>();
		sortedExercisesMap.put("Chest", new ArrayList<Exercise>());
		sortedExercisesMap.put("Shoulders", new ArrayList<Exercise>());
		sortedExercisesMap.put("Arms", new ArrayList<Exercise>());
		sortedExercisesMap.put("Legs", new ArrayList<Exercise>());
		sortedExercisesMap.put("Back", new ArrayList<Exercise>());
		sortedExercisesMap.put("Core", new ArrayList<Exercise>());
		
		exerciseMap.forEach((name, e) -> {
			sortedExercisesMap.get(e.getMuscleGroup()).add(e);
		});		
	}

	private void fetchTraineesFromDatabase() {
		ArrayList info = new ArrayList<>();
    	info.add(ClientController.client.globalUserID);
    	info.add("createPlan");
		ClientUI.chat.accept(new Message(MessageType.fetchTrainees, info));
		
	}
	
	private boolean existInTable(String e, String session) {
		for (TrainingPlanTableRow item : data) {
            if (item.getExercise().equals(e) && item.getSession().equals(session)) {
                return true;
            }
        }
        return false;
	}
	
	@FXML
    void clickTrainees(MouseEvent event) throws IOException {
		start(event, "trainerTrainee", "My Trainees");
    }

    @FXML
    void clickWeeklyReports(MouseEvent event) throws IOException {
    	start(event, "trainerWeeklyReportsMain", "Weekly Reports");
    }

}
