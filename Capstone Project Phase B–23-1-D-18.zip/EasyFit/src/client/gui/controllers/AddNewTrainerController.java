package client.gui.controllers;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import Entities.Message;
import Entities.MessageType;
import Entities.Specialty;
import Entities.Trainer;
import client.ClientController;
import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import sql.EncryptionUtils;

public class AddNewTrainerController extends AbstractController {

	 @FXML
	    private Text txtRequests;

	    @FXML
	    private Text txtTrainers;

	    @FXML
	    private Text txtTrainees;

	    @FXML
	    private TextField txtEmail;

	    @FXML
	    private PasswordField txtPassword;

	    @FXML
	    private TextField txtFirstName;

	    @FXML
	    private TextField txtLastName;

	    @FXML
	    private TextField txtID;

	    @FXML
	    private TextField txtPhone;

	    @FXML
	    private Button btnSave;

	    @FXML
	    private ChoiceBox<String> dropSpecialty;
	    
	    @FXML
	    private TextField txtGender;
	    
	    public static Map<String, Integer> specialtyMap;

		public static String status;
	    
    
    @FXML
    public void initialize() {
    	current.setOnCloseRequest(event -> {
    		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
    		System.exit(0);
    	});
    	fillSpecialty();
    }
    
    
    private void fillSpecialty() {
    	dropSpecialty.getItems().clear();
    	ClientUI.chat.accept(new Message(MessageType.getSpecialtyList, null));
    	System.out.println(specialtyMap);
    	for (Map.Entry<String, Integer> entry : specialtyMap.entrySet()) {
    		String key = entry.getKey();
            dropSpecialty.getItems().add(key);
        }
		
	}


	@FXML
    void clickRequests(MouseEvent event) throws IOException {
    	start(event, "managerRequestMain", "Trainee Requests");
    }

    @FXML
    void clickTrainees(MouseEvent event) throws IOException {
    	start(event, "managerTrainees", "Trainees");
    }

    @FXML
    void clickTrainers(MouseEvent event) throws IOException {
    	startManager(event, "managerManagingTrainers", "Manage Trainers");
    }
    
    @FXML
    void save(ActionEvent event) throws NoSuchAlgorithmException {
    	if(validate()) {
    		String hashedPassword = EncryptionUtils.hashPassword(txtPassword.getText());
    		String email = txtEmail.getText();
    		String first = txtFirstName.getText();
    		String last = txtLastName.getText();
    		String id = txtID.getText();
    		String phone = txtPhone.getText();
    		Specialty s = new Specialty(specialtyMap.get(dropSpecialty.getValue()), dropSpecialty.getValue());
    		String gender = txtGender.getText();
    		Trainer t = new Trainer(Integer.parseInt(id), email, hashedPassword, first, last, phone, s, false, gender);
    		ClientUI.chat.accept(new Message(MessageType.addNewTrainer, t));
    		showAlert(AlertType.INFORMATION, "Add Trainer", "Add Trainer", status);
    	}
    }


	private boolean validate() {
		if(txtEmail.getText().isEmpty()) {
			showAlert(AlertType.ERROR, "Add new Trainer", "Add new Trainer", "Email Required");
			return false;
		}
		if(txtPassword.getText().isEmpty()) {
			showAlert(AlertType.ERROR, "Add new Trainer", "Add new Trainer", "Password Required");
			return false;
		}
		if(txtFirstName.getText().isEmpty()) {
			showAlert(AlertType.ERROR, "Add new Trainer", "Add new Trainer", "First Name Required");
			return false;
		}
		if(txtLastName.getText().isEmpty()) {
			showAlert(AlertType.ERROR, "Add new Trainer", "Add new Trainer", "Last Name Required");
			return false;
		}
		if(txtID.getText().isEmpty()) {
			showAlert(AlertType.ERROR, "Add new Trainer", "Add new Trainer", "ID Required");
			return false;
		}
		if(txtPhone.getText().isEmpty()) {
			showAlert(AlertType.ERROR, "Add new Trainer", "Add new Trainer", "Phone Required");
			return false;
		}
		if(txtGender.getText().isEmpty()) {
			showAlert(AlertType.ERROR, "Add new Trainer", "Add new Trainer", "Gender Required");
			return false;
		}
		if(txtGender.getText().equals("male") || txtGender.getText().equals("female")) {
			return true;
		}else {
			showAlert(AlertType.ERROR, "Add new Trainer", "Add new Trainer", "Gender is male or female");
			return false;
		}
		
	}

}
