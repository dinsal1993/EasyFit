package client.gui.controllers;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Entities.Message;
import Entities.MessageType;
import Entities.WeeklyReport;
import client.ClientController;
import client.ClientUI;
import client.Main;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Popup;
import javafx.stage.Stage;
import sql.DBConnect;
import sql.EncryptionUtils;

public class LoginController extends AbstractController  {

    @FXML
    private TextField txtEmail;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private Button btnLogin;

    @FXML
    private Hyperlink btnForgotPassword;

    @FXML
    private Hyperlink btnSignUp;
    
    @FXML
    private Label lblError;
    

    public static String role;
    public static String errorMsg = "";

    @FXML
    void forgotPassword(ActionEvent event) {
    	//TODO: open forgot password window
    }
    
    @FXML
    void login(ActionEvent event) throws NoSuchAlgorithmException, IOException {
    	
    	//check if input fields are empty
    	if(txtEmail.getText().isEmpty() || txtPassword.getText().isEmpty())
    		lblError.setText("Please fill all fields");
    	//validate information. message details are seperated by !
    	else {
    		StringBuilder info = new StringBuilder();
    		info.append(txtEmail.getText());
    		info.append("!");
    		
    		String hashedPassword = EncryptionUtils.hashPassword(txtPassword.getText());
    		info.append(hashedPassword);
    		ClientUI.chat.accept(new Message(MessageType.login, info.toString()));
    		
    		if(errorMsg != "") {
    			showAlert(AlertType.ERROR, "Error", "Error", errorMsg);
    			
    		}
    		else {
    			switch(role) {
    			case "manager":
    				start(event, "managerRequestMain", "Trainee Requests");
    				break;
    			case "trainer":
    				start(event, "createTrainingPlan", "New Training Plan");
    				break;
    			case "trainee":
    				start(event, "viewTrainingPlan", "My Training Plan");
    				break;
    			}
    		}
    	}
    }

    @FXML
    void signUp(ActionEvent event) throws IOException {
    	start(event, "signUp", "SignUp");
    }
    
    public void start(Stage primaryStage) throws IOException {
		//FXMLLoader loader = new FXMLLoader(getClass().getResource("../fxml/login.fxml"));
    	FXMLLoader loader = new FXMLLoader(Main.class.getResource("gui/fxml/login.fxml"));
		Parent root = loader.load();

		Scene scene = new Scene(root);
		primaryStage.setTitle("EasyFit login");
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		current = primaryStage;
		primaryStage.setOnCloseRequest(event -> {
			System.exit(0);
		});
		
		primaryStage.show();
    }

}
