package client.gui.controllers;

import java.io.IOException;
import java.time.Year;
import java.util.ArrayList;

import Entities.Feedback;
import Entities.Message;
import Entities.MessageType;
import client.ClientController;
import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class TrainerFeedbackController extends AbstractController {

	@FXML
    private Text txtTrainingPlan;

    @FXML
    private Text txtWeeklyReports;

    @FXML
    private Text txtRequests;

    @FXML
    private TextField txtExerciseFeedback;

    @FXML
    private TextField txtMainFeedback;

    @FXML
    private ComboBox<String> dropYear;

    @FXML
    private ComboBox<String> dropMonth;

    @FXML
    private ComboBox<String> dropWeek;
    
    public static ArrayList<Feedback> traineeFeedbacks;

    @FXML
    public void initialize() {
    	current.setOnCloseRequest(event -> {
    		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
    		System.exit(0);
    	});
    	
    	getTraineeFeedbacks(ClientController.client.globalUserID);
    	fillBoxes();
    	 dropYear.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> handleChoiceBoxes());
         dropMonth.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> handleChoiceBoxes());
         dropWeek.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> handleChoiceBoxes());
    }



	private void fillBoxes() {
		ObservableList<String> months = FXCollections.observableArrayList();
		ObservableList<String> weeks = FXCollections.observableArrayList();
		ObservableList<String> years = FXCollections.observableArrayList();
        for (int i = 1; i <= 12; i++) 
            months.add(String.valueOf(i));
        weeks.addAll("1", "2", "3", "4");
        
        Year currentYear = Year.now();
        int yearValue = currentYear.getValue();
        int min = yearValue;
        for(Feedback fb : traineeFeedbacks) {
        	if (fb.getYear() < min)
        		min = fb.getYear();
        }
        for(int i = min; i <= yearValue; i++)
        	years.add(String.valueOf(i));
        
        dropYear.setItems(years);
        dropMonth.setItems(months);
        dropWeek.setItems(weeks);
	}



	private void handleChoiceBoxes() {
		String value1 = dropYear.getValue();
        String value2 = dropMonth.getValue();
        String value3 = dropWeek.getValue();

        if (value1 != null && value2 != null && value3 != null) {
            // All choice boxes have values selected
        	 for (Feedback feedback : traineeFeedbacks) {
        		 if(Integer.parseInt(value1) == feedback.getYear() &&
        				 Integer.parseInt(value2) == feedback.getMonth() && 
        				 Integer.parseInt(value3) == feedback.getWeek()) {
        			 txtMainFeedback.setText(feedback.getNotes());
        			 txtExerciseFeedback.setText(feedback.getExercisesNotes());
        			 return;
        		 }
        	 }
        }

	}

	private void getTraineeFeedbacks(int globalUserID) {
		ClientUI.chat.accept(new Message(MessageType.getTraineeFeedbacks, 
				ClientController.client.globalUserID));	
	}

	@FXML
    void clickRequests(MouseEvent event) throws IOException {
    	start(event, "traineeRequest", "My Requests");
    }

    @FXML
    void clickTrainingPlan(MouseEvent event) throws IOException {
    	start(event, "viewTrainingPlan", "My Training Plan");
    }

    @FXML
    void clickWeeklyReports(MouseEvent event) throws IOException {
    	start(event, "weeklyReports", "My Reports");
    }

}

