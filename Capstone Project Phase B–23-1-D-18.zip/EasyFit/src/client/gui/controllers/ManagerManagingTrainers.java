package client.gui.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import Entities.Message;
import Entities.MessageType;
import Entities.TrainingPlanTableRow;
import client.ClientController;
import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class ManagerManagingTrainers extends AbstractController{

	@FXML
    private Text txtNewTrainer;

    @FXML
    private Text txtRequests;

    @FXML
    private Text txtTrainees;

    @FXML
    private ChoiceBox<String> dropTrainers;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnRemove;

    @FXML
    private ListView<String> lstTrainees;
    
    public static Map<String, Integer> trainers;
    private String currTrainerID;
    private String currTrainerName;
    public static Map<Integer, String> traineeMap;
    public static String status;
    
    @FXML
    public void initialize() {
    	current.setOnCloseRequest(event -> {
    		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
    		System.exit(0);
    	});
    	
    	fillTrainers();
    }

    private void fillTrainers() {
    	ClientUI.chat.accept(new Message(MessageType.getTrainers, null));
    	System.out.println("back: trainers: " +trainers );	
	}

	@FXML
    void clickNewTrainer(MouseEvent event) throws IOException {
    	start(event, "addNewTrainer", "Add New Trainer");
    }

    @FXML
    void clickRequests(MouseEvent event) throws IOException {
    	start(event, "managerRequestMain", "Trainee Requests");
    }

    @FXML
    void clickTrainees(MouseEvent event) throws IOException {
    	start(event, "managerTrainees", "Trainees");
    }
    
    @FXML
    void addNewTrainee(ActionEvent event) {
    	if(validateAdd()) {
    		// Create a text input dialog
    		TextInputDialog dialog = new TextInputDialog();
    		dialog.setTitle("Enter trainee ID");
    		dialog.setHeaderText("Enter trainee ID");
    		dialog.setContentText("ID:");

    		// Show the dialog and wait for user input
    		dialog.showAndWait().ifPresent(traineeID -> {
    			ArrayList info = new ArrayList<>();
    			info.add(Integer.parseInt(currTrainerID));
    			info.add(Integer.parseInt(traineeID));
    			ClientUI.chat.accept(new Message(MessageType.addTraineeToTrainer, info));
    			showAlert(AlertType.CONFIRMATION, "Add Trainee to trainer", "Add Trainee to trainer", "success");
    		});
    	}else
    		showAlert(AlertType.ERROR, "Add Trainee to trainer", "Add Trainee to trainer", "No trainer selected");
    }
    
    private boolean validateAdd() {
    	boolean isSelected = dropTrainers.getSelectionModel().getSelectedItem() != null;
    	return isSelected;
	}

	@FXML
    void removeTrainee(ActionEvent event) {
    	// Get the selected item from lstTrainees
        String selectedTrainee = lstTrainees.getSelectionModel().getSelectedItem();

        if (selectedTrainee != null) {
        	ClientUI.chat.accept(new Message(MessageType.removeTraineeFromTrainer, Integer.parseInt(selectedTrainee)));
        	showAlert(AlertType.CONFIRMATION, "Manage Trainers", "Manage Trainers", status);
        }
    }

	public void start() {
		for (Map.Entry<String, Integer> entry : trainers.entrySet()) {
            String key = entry.getKey();
            int value = entry.getValue();
            System.out.println(key + " " + value);
            dropTrainers.getItems().add(String.valueOf(value) + ", " + key);
        }
		
		dropTrainers.setOnAction(event -> {
			if(dropTrainers != null) {
				currTrainerID = dropTrainers.getValue().split(", ")[0];
	            currTrainerName = dropTrainers.getValue().split(", ")[1];
	            ArrayList info = new ArrayList<>();
	            info.add(Integer.parseInt(currTrainerID));
	            info.add("manager");
	            ClientUI.chat.accept(new Message(MessageType.fetchTrainees, info));
	            
	            lstTrainees.getItems().clear();
	            for (Map.Entry<Integer, String> entry : traineeMap.entrySet()) {
	                int key = entry.getKey();
	                String value = entry.getValue();
	                
	                
	                lstTrainees.getItems().add(String.valueOf(key));
	            }
			}
    		
        });
		
	}

}
