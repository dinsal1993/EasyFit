package client.gui.controllers;

import java.io.IOException;
import java.util.ArrayList;

import Entities.Message;
import Entities.MessageType;
import Entities.Trainee;
import Entities.TrainerTraineeTableRow;
import Entities.TrainingPlanTableRow;
import client.ClientController;
import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class TrainerTraineeController extends AbstractController {

    @FXML
    private Text txtCreate;

    @FXML
    private Text txtWeekly;

    @FXML
    private TableView<TrainerTraineeTableRow> tblTrainees;

    @FXML
    private Button btnDetails;

    @FXML
    private Button btnEdit;
    
    public static ObservableList<TrainerTraineeTableRow> data =
    		FXCollections.observableArrayList();
    public static ArrayList<TrainerTraineeTableRow> traineesList;

    @FXML
    void clickCreate(MouseEvent event) throws IOException {
		start(event, "createTrainingPlan", "Create New Training Plan");
    }

    @FXML
    void clickWeekly(MouseEvent event) throws IOException {
    	start(event, "trainerWeeklyReportsMain", "Weekly Reports");
    }

    @FXML
    void details(ActionEvent event) throws IOException {
    	String selectedId;
    	
    	TrainerTraineeTableRow selected = tblTrainees.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selectedId = String.valueOf(selected.getTraineeID());
            start3(event, "signUp", "View Trainee Details!" + selectedId);
        }
        else 
        	showAlert(AlertType.ERROR, "View Trainee Details", "View Trainee Details", "No Trainee Selected");
    }

    @FXML
    void editProgram(ActionEvent event) throws IOException {
    	String selectedId;
    	
    	TrainerTraineeTableRow selected = tblTrainees.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selectedId = String.valueOf(selected.getTraineeID());
            start2(event, "createTrainingPlan", "Edit Plan!" + selectedId);
        }
        else 
        	showAlert(AlertType.ERROR, "Edit Program", "Edit Program", "No Trainee Selected");
    }
    
    @FXML
    public void initialize() {
        defineTable();
        fillTable();
       
        current.setOnCloseRequest(event -> {
        	ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
        	System.exit(0);
        });
        
    }

	private void fillTable() {
		ClientUI.chat.accept(new Message(MessageType.getTraineesRowData, ClientController.client.globalUserID));
		
		tblTrainees.getItems().clear();
		for(TrainerTraineeTableRow tr : traineesList)
			tblTrainees.getItems().add(tr);
	}

	private void defineTable() {
		// Define table columns
	    TableColumn<TrainerTraineeTableRow, Integer> idColumn = new TableColumn<>("ID");
	    idColumn.setCellValueFactory(new PropertyValueFactory<>("traineeID"));

	    TableColumn<TrainerTraineeTableRow, String> nameColumn = new TableColumn<>("Name");
	    nameColumn.setCellValueFactory(new PropertyValueFactory<>("traineeName"));

	    TableColumn<TrainerTraineeTableRow, String> phoneColumn = new TableColumn<>("Phone");
	    phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));

	    TableColumn<TrainerTraineeTableRow, String> emailColumn = new TableColumn<>("Email");
	    emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
	    
	    TableColumn<TrainerTraineeTableRow, Integer> ageColumn = new TableColumn<>("Age");
	    ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));
	    
	    TableColumn<TrainerTraineeTableRow, String> genderColumn = new TableColumn<>("Gender");
	    genderColumn.setCellValueFactory(new PropertyValueFactory<>("gender"));

	    // Add the columns to the TableView
	    tblTrainees.getColumns().addAll(idColumn, nameColumn, phoneColumn,
	    		emailColumn, ageColumn, genderColumn);

	    // Bind the data to the TableView
	    tblTrainees.setItems(data);
		
	}

}
