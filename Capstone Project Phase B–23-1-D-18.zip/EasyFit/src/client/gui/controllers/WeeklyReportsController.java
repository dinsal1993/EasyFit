package client.gui.controllers;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import Entities.Exercise;
import Entities.Message;
import Entities.MessageType;
import Entities.Session;
import Entities.WeeklyReport;
import client.ClientController;
import client.ClientUI;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

public class WeeklyReportsController extends AbstractController {
	public static String name = "";
	public static Map<String, Session> sessions;
	public static Map<String, String> exerciseNotes = new HashMap<>();
	public static byte[] fileData;
	public static int trainerID;
	
    @FXML
    private Text txtTrainingPlan;

    @FXML
    private Text txtTrainerFeedback;

    @FXML
    private Text txtRequests;
    
    @FXML
    private TextField txtName;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtSessionsPerformed;

    @FXML
    private TextField txtWeight;

    @FXML
    private TextArea txtNotes;

    @FXML
    private FontAwesomeIconView filePicker;

    @FXML
    private TextArea txtNotesInExercise;

    @FXML
    private ChoiceBox<String> dropExercise;

    @FXML
    private ListView<String> listExercises;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnFinish;
    
    @FXML
    private Button btnRemove;
    
    @FXML
    public void initialize() {
    	current.setOnCloseRequest(event -> {
    		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
    		System.exit(0);
    	});

    	txtID.setText(String.valueOf(ClientController.client.globalUserID));
    	
    	ArrayList info = new ArrayList();
    	info.add(ClientController.client.globalUserID);
    	info.add("weekly");
    	ClientUI.chat.accept(new Message(MessageType.getName, info));
    	
    	ArrayList x = new ArrayList();
    	x.add(ClientController.client.globalUserID);
    	x.add("weeklyForTrainer");
    	ClientUI.chat.accept(new Message(MessageType.getTrainerID, x));
    	txtName.setText(name);
    	
    	fillExercise();
    }

    private void fillExercise() {
    	ArrayList info = new ArrayList();
    	info.add(ClientController.client.globalUserID);
    	info.add("weekly");
    	System.out.println("before message weekly");
    	ClientUI.chat.accept(new Message(MessageType.getProgram, info));
    	System.out.println("after message weekly");
    	// Create a Set to store unique exercise names
        Set<String> exerciseNames = new HashSet<>();

        // Iterate through all the sessions in the map
        for (Session session : sessions.values()) {
            ArrayList<Exercise> exercises = session.getExercises();

            // Iterate through the exercises in each session
            for (Exercise exercise : exercises) {
                exerciseNames.add(exercise.getName());
            }
        }

        // Clear the existing items in the choice box
        dropExercise.getItems().clear();

        // Add the unique exercise names to the choice box
        dropExercise.getItems().addAll(exerciseNames);
		
	}

	@FXML
    void clickRequests(MouseEvent event) throws IOException {
    	start(event, "traineeRequest", "My Requests");
    }

    @FXML
    void clickTrainerFeedback(MouseEvent event) throws IOException {
    	start(event, "trainerFeedback", "My Feedbacks");
    }

    @FXML
    void clickTrainingPlan(MouseEvent event) throws IOException {
    	start(event, "viewTrainingPlan", "My Training Plan");
    }
    
    @FXML
    void addExerciseToList(ActionEvent event) {
    	String exerciseName = dropExercise.getValue();
        String exerciseNote = txtNotesInExercise.getText();

        // Check if exercise name is not empty and not already in the list
        if (exerciseName != null && !exerciseName.isEmpty() && !listExercises.getItems().contains(exerciseName)) {
            // Add exercise name to the list
            listExercises.getItems().add(exerciseName);

            // Save exercise note to the map
            // Assuming you have a Map<String, String> named "exerciseNotes" in the controller
            exerciseNotes.put(exerciseName, exerciseNote);
        }
    }



    @FXML
    void finish(ActionEvent event) {
    	if (validateSessionsPerformed() && validateWeight() && validateNotes()) {
    		int traineeID = ClientController.client.globalUserID;
    		int sessionsPerformed = Integer.parseInt(txtSessionsPerformed.getText());
    		int weight = Integer.parseInt(txtWeight.getText());
    		String notes = txtNotes.getText();
    		int year = LocalDate.now().getYear();
    		int month = LocalDate.now().getMonthValue();
    		int week = getWeek();
    		System.out.println("sending weekly report");
    		WeeklyReport wr = new WeeklyReport(traineeID, sessionsPerformed, weight, fileData,
    				notes, year, month, week, exerciseNotes, trainerID);
    		ClientUI.chat.accept(new Message(MessageType.addWeeklyReport, wr));
    		showAlert(AlertType.CONFIRMATION, "Add Weekly Report", "Add Weekly Report", "Success");
    	}else {
    		Alert a = new Alert(AlertType.ERROR, "must fill all inputs, at least one exercise"
    				+ " report");
    		a.showAndWait();
    	}
    }
    
    private int getWeek() {
    	int currentDayOfMonth = LocalDate.now().getDayOfMonth();
        int week = (currentDayOfMonth - 1) / 7 + 1;
        
        // Ensure the week value is within the range of 1-4
        if (week < 1) {
            week = 1;
        } else if (week > 4) {
            week = 4;
        }
        return week;
	}
    
    

	private boolean validateSessionsPerformed() {
        String sessionsPerformedText = txtSessionsPerformed.getText();
        try {
            int sessionsPerformed = Integer.parseInt(sessionsPerformedText);
            if (sessionsPerformed >= 1 && sessionsPerformed <= 10) {
                return true; // Valid input
            } else {
                // Invalid input: not within the valid range (1-10)
                return false;
            }
        } catch (NumberFormatException e) {
            // Invalid input: not a valid integer
            return false;
        }
    }
    
    private boolean validateWeight() {
        String weightText = txtWeight.getText();
        try {
            int weight = Integer.parseInt(weightText);
            if (weight >= 1 && weight <= 500) {
                return true; // Valid input
            } else {
                // Invalid input: not within the valid range (1-500)
                return false;
            }
        } catch (NumberFormatException e) {
            // Invalid input: not a valid integer
            return false;
        }
    }
    
    private boolean validateNotes() {
        String notesText = txtNotes.getText();
        if (notesText.isEmpty()) {
            // Invalid input: empty text
            return false;
        } else {
            return true; // Valid input
        }
    }
    


    @FXML
    void uploadFile(MouseEvent event) {
    	// Create a FileChooser instance
        FileChooser fileChooser = new FileChooser();
        
        // Set the title of the file picker dialog
        fileChooser.setTitle("Choose an Image File");
        
        // Set the file extension filters if desired (e.g., only allow image files)
        // fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        
        // Show the file picker dialog and get the selected file
        File selectedFile = fileChooser.showOpenDialog(null);
        
        if (selectedFile != null) {
            try {
                // Read the selected file as a byte array
                fileData = Files.readAllBytes(selectedFile.toPath());       
            } catch (IOException e) {
                // Handle any IO errors
                e.printStackTrace();
            }
        }
    }
    
    @FXML
    void removeExerciseFromList(ActionEvent event) {
    	String selectedItem = listExercises.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            // Remove the selected exercise from the list
            listExercises.getItems().remove(selectedItem);

            // Remove the exercise note from the map
            exerciseNotes.remove(selectedItem);
        }
    }
    
}
