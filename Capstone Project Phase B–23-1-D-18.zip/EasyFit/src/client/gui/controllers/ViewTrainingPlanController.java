package client.gui.controllers;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Map;

import Entities.Exercise;
import Entities.Message;
import Entities.MessageType;
import Entities.Session;
import Entities.TrainingPlanTableRow;
import client.ClientController;
import client.ClientUI;
import client.PDFGenerator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.print.PageLayout;
import javafx.print.PrinterJob;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ChoiceBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class ViewTrainingPlanController extends AbstractController {
	
    public static Map<String, Exercise> exerciseMap;
    private static ObservableList<TrainingPlanTableRow> data =
    		FXCollections.observableArrayList();
    public static Map<String, Session> sessions;

    @FXML
    private TableView<TrainingPlanTableRow> tblPlan;

    @FXML
    private Label lblDescription;

    @FXML
    private ImageView imgExercise;
    
    @FXML
    private Text txtTrainingPlan;

    @FXML
    void downloadPDF(MouseEvent event) {
    	System.out.println("Clicked download pdf");
    	//PDFGenerator.generatePDF(tblPlan, "table.pdf");
    	
    	FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save PDF File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));

        // Show save file dialog
        Stage stage = (Stage) tblPlan.getScene().getWindow();
        File outputFile = fileChooser.showSaveDialog(stage);

        if (outputFile != null) {
            String outputPath = outputFile.getAbsolutePath();
            PDFGenerator.generatePDF(tblPlan, outputPath);
        }
    }

    
    @FXML
    public void initialize() {
    	//Get list of exercises
    	ClientUI.chat.accept(new Message(MessageType.fetchExercises, "view"));
    	
    	ArrayList info = new ArrayList<>();
    	info.add(ClientController.client.globalUserID);
    	info.add("view");
    	//Get the trainee program
    	ClientUI.chat.accept(new Message(MessageType.getProgram,
    			info));
    	
        defineTable();
        fillTable();
       
        current.setOnCloseRequest(event -> {
        	ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
        	System.exit(0);
        });
        
    }

	private void fillTable() {
		for (Map.Entry<String, Session> entry : sessions.entrySet()) {
            String sessionTag = entry.getKey();
            Session session = entry.getValue();        
            
            // Iterate over the exercises, sets, and repetitions
            for (int i = 0; i < session.getExercises().size(); i++) {
                String exercise = session.getExercises().get(i).getName();
                String sets = session.getSets().get(i);
                String reps = session.getRepetitions().get(i);

                Hyperlink youtubeLink = new Hyperlink(session.getExercises().get(i).getVideo());
                
                youtubeLink.setOnAction(event -> {
            	    String url = exerciseMap.get(exercise).getVideo();
            	    if (Desktop.isDesktopSupported()) {
            	        Desktop desktop = Desktop.getDesktop();
            	        try {
            	            desktop.browse(new URI(url));
            	        } catch (IOException | URISyntaxException e) {
            	            System.out.println("No link provided");
            	        }
            	    }
            });

                // Create a new TrainingPlanTableRow and add it to the table
                tblPlan.getItems().add(new TrainingPlanTableRow(sessionTag, exercise, sets,
                		reps, youtubeLink));
            }
		}
		
	}

	@SuppressWarnings("unchecked")
	private void defineTable() {
		// Define table columns
	    TableColumn<TrainingPlanTableRow, String> sessionColumn = new TableColumn<>("session");
	    sessionColumn.setCellValueFactory(new PropertyValueFactory<>("session"));

	    TableColumn<TrainingPlanTableRow, String> exerciseColumn = new TableColumn<>("exercise");
	    exerciseColumn.setCellValueFactory(new PropertyValueFactory<>("exercise"));

	    TableColumn<TrainingPlanTableRow, String> setsColumn = new TableColumn<>("sets");
	    setsColumn.setCellValueFactory(new PropertyValueFactory<>("sets"));

	    TableColumn<TrainingPlanTableRow, String> repsColumn = new TableColumn<>("reps");
	    repsColumn.setCellValueFactory(new PropertyValueFactory<>("reps"));
	    
	    TableColumn<TrainingPlanTableRow, Hyperlink> linkColumn = new TableColumn<>("youtube");
	    linkColumn.setCellValueFactory(new PropertyValueFactory<>("link"));

	    // Add the columns to the TableView
	    tblPlan.getColumns().addAll(sessionColumn, exerciseColumn, setsColumn,
	    		repsColumn, linkColumn);

	    // Bind the data to the TableView
	    tblPlan.setItems(data);
		
	}
	
	// Navigation
	@FXML
    void clickRequests(MouseEvent event) throws IOException {
		start(event, "traineeRequest", "My Requests");
    }

    @FXML
    void clickTrainerFeedback(MouseEvent event) throws IOException {
    	start(event, "trainerFeedback", "Trainer Feedbacks");
    }

    @FXML
    void clickWeeklyReports(MouseEvent event) throws IOException {
    	start(event, "weeklyReports", "My Weekly Reports");
    }

}
