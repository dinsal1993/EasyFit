package client.gui.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import Entities.Goal;
import Entities.Message;
import Entities.MessageType;
import Entities.Request;
import Entities.Trainer;
import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class ManagerHandlingTraineeRequestController extends AbstractController {

    @FXML
    private Text txtAddTrainer;

    @FXML
    private Text txtRequests;

    @FXML
    private Text txtTrainers;

    @FXML
    private Text txtTrainees;

    @FXML
    private TextField txtTrainee;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtTrainer;

    @FXML
    private TextField txtType;

    @FXML
    private TextField txtReason;

    @FXML
    private Button btnConfirm;

    @FXML
    private Button btnReject;

    @FXML
    private ChoiceBox<String> dropNew;

    @FXML
    private Slider sliderDuration;

    @FXML
    private Slider sliderActivity;

    @FXML
    private ChoiceBox<String> dropTarget;

    @FXML
    private ChoiceBox<String> dropWeekly;
    
    @FXML
    private Text txtDuration;

    @FXML
    private Text txtWeekly;

    @FXML
    private Text txtDaily;
    
    @FXML
    private Text txtTarget;
    
    public static Request req;
    public static ArrayList<String> names = new ArrayList<>();
    public static ArrayList<Trainer> trainers;
    public static String result;

    @FXML
    void confirm(ActionEvent event) {
    	if(validate()) {
    		String newTrainerID = dropNew.getValue().split(", ")[0];
    		ArrayList info = new ArrayList<>();
    		info.add(req);
    		info.add(newTrainerID);
    		if(req.getType().equals("Target")){
    			ClientUI.chat.accept(new Message(MessageType.confirmRequestTarget, info));
    			showAlert(AlertType.CONFIRMATION, "Confirm Request", "Confirm Request", result);
    		}else {
    			ClientUI.chat.accept(new Message(MessageType.confirmRequestTrainer, info));
    			showAlert(AlertType.CONFIRMATION, "Confirm Request", "Confirm Request", result);
    		}
    		
    	}
    }

    private boolean validate() {
		if(dropNew.getValue() == null) {
			showAlert(AlertType.ERROR, "Handle Request", "Handle Request", "Must input new Trainer");
			return false;
		}
		return true;
	}

	@FXML
    void reject(ActionEvent event) {
		ClientUI.chat.accept(new Message(MessageType.rejectRequest, req));

    }

	public void start(int requestID,int traineeID, int trainerID) {
		ArrayList info1 = new ArrayList<>();
		info1.add(requestID);
		info1.add("handling");
		ClientUI.chat.accept(new Message(MessageType.getRequest, info1));
		
		System.out.println("request is: " + req);
		
		ArrayList info = new ArrayList<>();
		info.add(traineeID);
		info.add("handleRequest");
		ClientUI.chat.accept(new Message(MessageType.getName, info));
		System.out.println("name 1: " +names.get(0));
		
		info.clear();
		info.add(trainerID);
		info.add("handleRequest");
		ClientUI.chat.accept(new Message(MessageType.getName, info));
		System.out.println("name 2: " +names.get(1));
		System.out.println("ID: " + traineeID);
		if(req.getType().equals("Target")) {
			ArrayList info2 = new ArrayList<>();
			info2.add(req.getGoal());
			info2.add("handling");
			ClientUI.chat.accept(new Message(MessageType.getTrainersByTarget, info2));
			setVisibleTarget(true);
			setFieldsTarget(traineeID);
		}else {
			ClientUI.chat.accept(new Message(MessageType.getTrainersByTrainer, trainerID));
			setVisibleTarget(false);
			setFieldsTrainer(traineeID);
		}
		
		ArrayList<String> trainerList = new ArrayList<>();
		for(Trainer t : trainers)
			trainerList.add(t.getTrainerID() + ", " + t.getFirstName() + " " + t.getLastName());
		dropNew.getItems().addAll(trainerList);
	}

	private void setFieldsTrainer(int traineeID) {
		txtTrainee.setText(names.get(0));
		txtID.setText(String.valueOf(traineeID));
		txtTrainer.setText(names.get(1));
		txtType.setText(req.getType());
		txtReason.setText(req.getDetails());
		
	}

	private void setFieldsTarget(int traineeID) {
		txtTrainee.setText(names.get(0));
		txtID.setText(String.valueOf(traineeID));
		txtTrainer.setText(names.get(1));
		txtType.setText(req.getType());
		txtReason.setText(req.getDetails());
		dropTarget.getItems().add(req.getGoal());
		dropTarget.setValue(req.getGoal());
		dropWeekly.getItems().add(String.valueOf(req.getSessionsPerWeek()));
		dropWeekly.setValue(String.valueOf(req.getSessionsPerWeek()));
		sliderActivity.setValue(req.getActivityLevel());;
		sliderDuration.setValue(req.getSessionDuration());
		
	}

	private void setVisibleTarget(boolean b) {
		txtTarget.setVisible(b);
		txtDuration.setVisible(b);
		txtWeekly.setVisible(b);
		txtDaily.setVisible(b);
		
		dropTarget.setVisible(b);
		dropWeekly.setVisible(b);
		sliderActivity.setVisible(b);
		sliderDuration.setVisible(b);
	}
	
	@FXML
    void clickAddTrainer(MouseEvent event) throws IOException {
		start(event, "addNewTrainer", "Add New Trainer");
    }

    @FXML
    void clickRequests(MouseEvent event) throws IOException {
    	start(event, "managerRequestMain", "Trainee Requests");
    }

    @FXML
    void clickTrainees(MouseEvent event) throws IOException {
    	start(event, "managerTrainees", "Trainees");
    }

    @FXML
    void clickTrainers(MouseEvent event) throws IOException {
    	startManager(event, "managerManagingTrainers", "Manage Trainers");
    }

}
