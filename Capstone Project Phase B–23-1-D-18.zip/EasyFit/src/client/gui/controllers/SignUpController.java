package client.gui.controllers;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;

import Entities.Goal;
import Entities.Message;
import Entities.MessageType;
import Entities.Request;
import Entities.Target;
import Entities.Trainee;
import Entities.Trainer;
import client.ClientUI;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import sql.EncryptionUtils;

public class SignUpController extends AbstractController {

    @FXML
    private TextField txtFirst;

    @FXML
    private TextField txtLast;

    @FXML
    private DatePicker date;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtEmail;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private TextField txtPhone;

    @FXML
    private TextField txtCountry;

    @FXML
    private TextField txtStreet;

    @FXML
    private TextField txtCity;

    @FXML
    private Button btnBack;

    @FXML
    private Slider sliderDuration;

    @FXML
    private Slider sliderActivity;

    @FXML
    private ChoiceBox<Goal> dropTarget;

    @FXML
    private ChoiceBox<Integer> dropWeekly;

    @FXML
    private TextField txtOther;

    @FXML
    private TextField txtWeight;

    @FXML
    private TextField txtHeight;

    @FXML
    private TextField txtMedical;

    @FXML
    private Button btnSave;
    
    @FXML
    private FontAwesomeIconView fileUpload;
    
    @FXML
    private Text txtTitle;
    
    @FXML
    private Text txtPhoto;
    
    @FXML
    private ChoiceBox<String> dropGender;
    
    @FXML
    private ChoiceBox<String> dropTrainer;
    
    @FXML
    private Button btnConfirm;

    @FXML
    private Button btnReject;
    
    @FXML
    private Text txtTrainer;
    
    private String reqID;
    
    public static String requestReturn;
    
    Alert a;
    private static final int MINIMUM_AGE = 10;
    public static String createStatus = "";
    public static byte[] fileData = null;
    public static ArrayList arrForEdit;
    public static Request request;
    public static ArrayList<Trainer> trainers;

    @FXML
    void back(ActionEvent event) throws IOException {
    	start(event, "Login", "Login");
    }

    @FXML
    void save(ActionEvent event) throws Exception {
    	Trainee trainee = null;
    	Target targetObject = null;
    	String result = checkFields();
    	if (!result.equals("OK")) {
    		showAlert(AlertType.ERROR, "SignUp", "SignUp", result);
    	}
    	else {
    		int id;
    		String email, password, firstName, lastName, phone, address, medical, target,
    		hashedPassword, encryptedMedical, gender;
    		int birthYear, birthMonth, weight, height, trainingDuration,
    		weeklySessions, dailyActivity, age;
    		
    		//Collect data for new trainee
    		id = Integer.parseInt(txtID.getText());
    		email = txtEmail.getText();
    		
    		password = txtPassword.getText();
    		hashedPassword = EncryptionUtils.hashPassword(password);
    		
    		firstName = txtFirst.getText();
    		lastName = txtLast.getText();
    		phone = txtPhone.getText();
    		address = txtStreet.getText() + ", " + txtCity.getText() + ", " +
    		txtCountry.getText();
    		
    		LocalDate selectedDate = date.getValue();
    		birthYear = selectedDate.getYear();
    		birthMonth = selectedDate.getMonthValue();
    		age = Year.now().getValue() - birthYear;
    		weight = Integer.parseInt(txtWeight.getText());
    		height = Integer.parseInt(txtHeight.getText());
    		target = dropTarget.getValue() == null ? txtOther.getText() :
    			dropTarget.getValue().toString();
    		trainingDuration = (int)sliderDuration.getValue();
    		weeklySessions = Integer.parseInt(dropWeekly.getValue().toString());
    		dailyActivity = (int)sliderActivity.getValue();
    		
    		medical = txtMedical.getText().isEmpty()? "" : txtMedical.getText();
    		EncryptionUtils.createPrimeKey(firstName, lastName, String.valueOf(id));
    		encryptedMedical = EncryptionUtils.encrypt(medical);
    		gender = dropGender.getValue();
    		ArrayList<Object> info = new ArrayList<Object>();
    		trainee = new Trainee(id, email, hashedPassword, firstName, lastName, phone, address,
    				weight, height, birthYear, birthMonth, age, fileData, encryptedMedical, false, false, gender);
    		targetObject = new Target(id, target, weeklySessions, trainingDuration, dailyActivity);
    		info.add(trainee);
    		info.add(targetObject);
    		
    		ClientUI.chat.accept(new Message(MessageType.createTrainee, info));
    		
    		if(createStatus.equals("Success")) {
    			EncryptionUtils.createPrimeKey("asd", "dsadasd", "123123");
    			ClientUI.chat.accept(new Message(MessageType.getDecryptionKey, String.valueOf(id)));
    			System.out.println("key is: " + EncryptionUtils.getKey(String.valueOf(id)));
    			System.out.println("decrypted: " + EncryptionUtils.decrypt(encryptedMedical));
    			a = new Alert(AlertType.INFORMATION, createStatus);
        		a.showAndWait();
        		start(event, "login", "Login");
    		}
    		else {
    			a = new Alert(AlertType.ERROR, createStatus);
        		a.show();
    		}
    	}
    }

	private String checkFields() {
		boolean id = txtID.getText().isEmpty() || (txtID.getText().length() < 0 ||
				txtID.getText().length() > 9) || containAlphabet(txtID.getText());
		boolean email = txtEmail.getText().isEmpty();
		boolean password = txtPassword.getText().isEmpty();
		boolean firstName = txtFirst.getText().isEmpty() || containDigits(txtFirst.getText());
		boolean lastName = txtLast.getText().isEmpty() || containDigits(txtLast.getText());
		boolean phone = txtPhone.getText().isEmpty() || containAlphabet(txtPhone.getText());
		boolean address = txtStreet.getText().isEmpty() || txtCity.getText().isEmpty() ||
				txtCountry.getText().isEmpty();
		
		LocalDate selectedDate = date.getValue();
		boolean selectedDateCheck = date.getValue() == null;
		LocalDate currentDate = LocalDate.now();
		boolean birthYear = selectedDate.getYear() > currentDate.getYear();
		boolean birthMonth = selectedDate.getMonthValue() > currentDate.getMonthValue();
		boolean age = (Year.now().getValue() - selectedDate.getYear()) < MINIMUM_AGE;
		boolean weight = txtWeight.getText().isEmpty() ||
				containAlphabet(txtWeight.getText()) || txtWeight.getText().length()>3;
		boolean height = txtHeight.getText().isEmpty() ||
				containAlphabet(txtHeight.getText()) || txtHeight.getText().length() > 3;
		boolean target = dropTarget.getValue() == null && txtOther.getText().isEmpty();
		boolean weeklySessions = dropWeekly.getValue() == null;
		boolean gender = dropGender.getValue() == null;
			
		if (id) 
	        return "Invalid ID (must not be empty, length should be less than or"
	        		+ " equal to 9 and not contain alphabetic characters)";
	    
		if (email) 
	        return "Email is required";

	    if (password) 
	        return "Password is required";
	    
	    if (firstName) 
	        return "Invalid first name (must not be empty and should not contain digits)";
	    
	    if (lastName) 
	        return "Invalid last name (must not be empty and should not contain digits)";
	    
	    if (phone) 
	        return "Invalid phone number (must not be empty and should not contain"
	        		+ " alphabetic characters)";
	    
	    if (address) 
	        return "Address fields are required";
	    
	    if (selectedDateCheck) 
	        return "Date of birth is required";
	    
	    if (birthYear) 
	        return "Invalid birth year";
	    
	    if (birthMonth) 
	        return "Invalid birth month";
	    
	    if (age) 
	        return "Minimum registration age is 10";
	    
	    if (weight) 
	        return "Invalid weight (must not be empty, should not contain alphabetic"
	        		+ " characters and weight must be less than 1000 kg)";
	    
	    if (height) 
	        return "Invalid height (must not be empty, should not contain alphabetic"
	        		+ " characters and must be less than 999 cm)";
	    
	    if (target) 
	        return "Target field is required";
	    
	    if (weeklySessions) 
	        return "Weekly sessions field is required";
	    if(gender)
	    	return "Gender field is required";
	    
	    return "OK";
			
	}
	
	private static boolean containDigits(String input) {
	    return input.matches(".*\\d.*");
	}
	
	private static boolean containAlphabet(String input) {
	    return input.matches(".*[a-zA-Z].*");
	}

	@FXML
    private void initialize() {
		createStatus = "";
        fillTarget();
        fillWeeklySessions();
        fillGender();
        txtTrainer.setVisible(false);
        dropTrainer.setVisible(false);
        dropTrainer.setDisable(true);
        btnConfirm.setVisible(false);
        btnConfirm.setDisable(true);
        btnReject.setVisible(false);
        btnReject.setDisable(true);
    }

	private void fillGender() {
		ObservableList<String> genderList = FXCollections.observableArrayList("male", "female");
		dropGender.setItems(genderList);
		
	}

	private void fillWeeklySessions() {
		ObservableList<Integer> weeklyList = FXCollections.observableArrayList(1,2,3,4,5,6,7);
		dropWeekly.setItems(weeklyList);
		
	}

	private void fillTarget() {
		ObservableList<Goal> goalList = FXCollections.observableArrayList(Goal.values());
		dropTarget.setItems(goalList);
	}
	
	@FXML
    void addPhoto(MouseEvent event) {
		
		if(!current.getTitle().contains("View")) {
			//In SignUp mode
			// Create a FileChooser instance
			System.out.println("not view mode");
	        FileChooser fileChooser = new FileChooser();
	        
	        // Set the title of the file picker dialog
	        fileChooser.setTitle("Choose an Image File");
	        
	        // Set the file extension filters if desired (e.g., only allow image files)
	        // fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
	        
	        // Show the file picker dialog and get the selected file
	        File selectedFile = fileChooser.showOpenDialog(null);
	        
	        if (selectedFile != null) {
	            try {
	                // Read the selected file as a byte array
	                fileData = Files.readAllBytes(selectedFile.toPath());       
	            } catch (IOException e) {
	                // Handle any IO errors
	                e.printStackTrace();
	            }
	        }
		}else { // In View mode
			System.out.println("view mode");
	        if (fileData != null) {
	            InputStream inputStream = new ByteArrayInputStream(fileData);
	            Image image = new Image(inputStream);
	            //imgPhoto.setImage(image);

	            Stage tempStage = new Stage();
	            tempStage.initStyle(StageStyle.DECORATED);

	            ImageView imageView = new ImageView(image); // Create a new ImageView
	            

	            Pane container = new Pane();
	            container.getChildren().add(imageView); // Add the ImageView to the container

	            Scene scene = new Scene(container);
	            
				/*
				 * tempStage.setWidth(800); // Set the width of the stage
				 * tempStage.setHeight(600); // Set the height of the stage
				 * 
				 * imageView.setPreserveRatio(true);
				 * imageView.fitWidthProperty().bind(tempStage.widthProperty());
				 * imageView.fitHeightProperty().bind(tempStage.heightProperty());
				 */
	            
	            imageView.setPreserveRatio(true);
	            imageView.setFitWidth(800);
	            imageView.setFitHeight(600);
	            imageView.setSmooth(true); // Optional: Enable image smoothing for better quality
	            
	            tempStage.setScene(scene);
	            tempStage.show();
	        }else //no photo
	        	showAlert(AlertType.ERROR, "Show Photo", "Show Photo", "No photo");
		}
		
    }

	public void checkEdit() throws Exception {
		if(current.getTitle().contains("View")) {
        	String[] info = current.getTitle().split("!");
        	if(!current.getTitle().contains("request"))
        		current.setTitle(info[0]);
        	txtTitle.setText("View Details");
        	
        	String traineeID = info[1];
        	System.out.println("id is: " + traineeID);
        	ClientUI.chat.accept(new Message(MessageType.getTraineesFullData, traineeID));
        	System.out.println("arr is: ");
        	System.out.println((Trainee)arrForEdit.get(0));
        	disableElements();
        	displayData();
        	System.out.println("contain request:" + current.getTitle().contains("request"));
        	if(current.getTitle().contains("request")) {
        		System.out.println("contain request");
        		txtTrainer.setVisible(true);
                dropTrainer.setVisible(true);
                dropTrainer.setDisable(false);
                btnConfirm.setVisible(true);
                btnConfirm.setDisable(false);
                btnReject.setVisible(true);
                btnReject.setDisable(false);
                reqID = info[3];
                ArrayList ra = new ArrayList<>();
                ra.add(Integer.parseInt(reqID));
                ra.add("signup");
                ClientUI.chat.accept(new Message(MessageType.getRequest, ra));
                System.out.println("request goal is: " + request.getGoal());
                ArrayList info1 = new ArrayList<>();
                info1.add(request.getGoal());
                info1.add("signup");
                ClientUI.chat.accept(new Message(MessageType.getTrainersByTarget,info1 ));
                for(Trainer t: trainers) {
                	dropTrainer.getItems().add(t.getTrainerID() + ", " + t.getFirstName() + " " + t.getLastName());
                }
                current.setTitle("SignUp Request");
        	}
        	
        }
		
	}

	private void displayData() throws Exception {
		Trainee trainee = (Trainee) arrForEdit.get(0);
		Target target = (Target) arrForEdit.get(1);
		
		txtEmail.setText(trainee.getEmail());
		txtFirst.setText(trainee.getFirstName());
		txtLast.setText(trainee.getLastName());
		txtID.setText(String.valueOf(trainee.getUserID()));
		date.setValue(LocalDate.of(trainee.getBirthYear(), trainee.getBirthMonth(), 1));
		txtPhone.setText(trainee.getPhone());
		
		String[] info = trainee.getAddress().split(", ");
		txtCountry.setText(info[0]);
		txtCity.setText(info[1]);
		txtStreet.setText(info[2]);
		txtWeight.setText(String.valueOf(trainee.getWeight()));
		txtHeight.setText(String.valueOf(trainee.getHeight()));
		txtOther.setText(target.getGoal());
		dropTarget.setDisable(true);
		sliderDuration.setValue(target.getSessionDuration());
		sliderActivity.setValue(target.getActivityLevel());
		dropWeekly.getItems().clear();
		dropWeekly.getItems().add(target.getSessionsPerWeek());
		dropWeekly.setValue(target.getSessionsPerWeek());
		
		txtPhoto.setText("View Photo");
		fileData = trainee.getPhoto();
		btnBack.setVisible(false);
		btnSave.setVisible(false);
		dropGender.getItems().clear();
		dropGender.getItems().add(trainee.getGender());
		dropGender.setValue(trainee.getGender());
		
		EncryptionUtils.createPrimeKey(trainee.getFirstName(), trainee.getLastName(), String.valueOf(trainee.getUserID()));
		String decryptedMedical = EncryptionUtils.decrypt(trainee.getMedical());
		txtMedical.setText(decryptedMedical);
	}

	private void disableElements() {
		txtEmail.setDisable(true);
		txtPassword.setDisable(true);
		txtFirst.setDisable(true);
		txtLast.setDisable(true);
		txtID.setDisable(true);
		date.setDisable(true);
		txtPhone.setDisable(true);
		txtCountry.setDisable(true);
		txtCity.setDisable(true);
		txtStreet.setDisable(true);
		txtWeight.setDisable(true);
		txtHeight.setDisable(true);
		txtOther.setDisable(true);
		dropTarget.setDisable(true);
		sliderDuration.setDisable(true);
		sliderActivity.setDisable(true);
		dropWeekly.setDisable(true);
		txtMedical.setDisable(true);
		btnBack.setDisable(true);
		btnSave.setDisable(true);
		dropGender.setDisable(true);
		
	}
	
	@SuppressWarnings("unchecked")
	@FXML
    void confirm(ActionEvent event) {
		//Request r = new Request(Integer.parseInt(reqID), Integer.parseInt(txtID.getText()), "", "", "", 0, 0, 0, "");
		ArrayList info = new ArrayList<>();
		info.add(request);
		info.add(Integer.parseInt(txtID.getText()));
		String temp = dropTrainer.getValue().split(", ")[0];
		info.add((Integer.parseInt(temp)));
		System.out.println("in client: request: " + request + ":::: traineeID: " +Integer.parseInt(txtID.getText()) + " ::::: trainerID: " +  (dropTrainer.getValue().split(", "))[0]);
		ClientUI.chat.accept(new Message(MessageType.confirmRequestSignUp, info));
		showAlert(AlertType.CONFIRMATION, "SignUp Request", "SignUp Request", requestReturn);
		current.close();
    }

    @FXML
    void reject(ActionEvent event) {
    	Request r = new Request(Integer.parseInt(reqID), 0, "", "", "", 0, 0, 0, "");
    	ClientUI.chat.accept(new Message(MessageType.rejectRequest, r));
    	showAlert(AlertType.CONFIRMATION, "SignUp Request", "SignUp Request", "Succes");
    	current.close();
    }

}
