package client.gui.controllers;

import java.io.IOException;

import Entities.Message;
import Entities.MessageType;
import client.ClientController;
import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class ManagerTraineesController extends AbstractController {

	@FXML
    private Text txtNewTrainer;

    @FXML
    private Text txtRequests;

    @FXML
    private Text txtTrainers;

    @FXML
    private Button btnRemove;

    @FXML
    private TextField txtID;
    
    public static String status;
    
    @FXML
    public void initialize() {
    	current.setOnCloseRequest(event -> {
    		ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
    		System.exit(0);
    	});
    }

    @FXML
    void clickNewTrainer(MouseEvent event) throws IOException {
    	start(event, "addNewTrainer", "Add New Trainer");
    }

    @FXML
    void clickRequests(MouseEvent event) throws IOException {
    	start(event, "managerRequestMain", "Trainee Requests");
    }

    @FXML
    void clickTrainers(MouseEvent event) throws IOException {
    	startManager(event, "managerManagingTrainers", "Manage Trainers");
    }
    
    @FXML
    void remove(ActionEvent event) {
    	if(txtID.getText().isEmpty())
    		showAlert(AlertType.ERROR, "Delete Trainee", "Delete Trainee", "No Trainee ID provided");
    	else {
    		try {
    			ClientUI.chat.accept(new Message(MessageType.deleteUser, Integer.parseInt(txtID.getText())));
        		showAlert(AlertType.ERROR, "Delete Trainee", "Delete Trainee", status);
    		}catch(NumberFormatException e) {
    			showAlert(AlertType.ERROR, "Delete Trainee", "Delete Trainee", "Not valid ID");
    		}
    		
    	}
    }

}
