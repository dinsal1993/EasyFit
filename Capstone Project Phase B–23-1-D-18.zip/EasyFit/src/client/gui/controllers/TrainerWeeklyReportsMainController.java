package client.gui.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;

import Entities.Message;
import Entities.MessageType;
import Entities.TrainingPlanTableRow;
import Entities.WeeklyReport;
import Entities.WeeklyReportsTableRow;
import client.ClientController;
import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class TrainerWeeklyReportsMainController extends AbstractController {

    @FXML
    private TableView<WeeklyReportsTableRow> tblReports;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnOpen;
    
    @FXML
    private Text txtCreate;

    @FXML
    private Text txtTrainees;
    
    private static ObservableList<WeeklyReportsTableRow> data =
    		FXCollections.observableArrayList();
    public static ArrayList<WeeklyReport> reports;
    public static Map<Integer, String> names;

    @FXML
    void delete(ActionEvent event) {

    }

    @FXML
    void open(ActionEvent event) throws IOException {
    	// Get the selected row
        WeeklyReportsTableRow selectedRow = tblReports.getSelectionModel().getSelectedItem();
        
        if (selectedRow != null) {
            // Extract the Weekly Report
        	int traineeID = selectedRow.getTraineeID();
            int year = selectedRow.getYear();
            int month = selectedRow.getMonth();
            int week = selectedRow.getWeek();
        	WeeklyReport wr = getReport(traineeID, year, month, week);
        	start(event, "trainerWeeklyReport2", "Single Report", wr);
        }
    }
    
    private WeeklyReport getReport(int traineeID, int year, int month, int week) {
		for(WeeklyReport wr : reports) {
			if (wr.getTraineeID() == traineeID && wr.getYear() == year &&
					wr.getMonth() == month && wr.getWeek() == week) {
				return wr;
			}
		}
		return null;
	}

	@FXML
    public void initialize() {
    	//Get list of reports
    	ArrayList info = new ArrayList<>();
    	info.add(ClientController.client.globalUserID);
    	info.add("reports");
    	ClientUI.chat.accept(new Message(MessageType.getTraineeReports, ClientController.client.globalUserID));
    	ClientUI.chat.accept(new Message(MessageType.fetchTrainees, info));
        defineTable();
        reports.sort(
        	    Comparator.comparing(WeeklyReport::getStatus)
        	              .thenComparing(WeeklyReport::getTraineeID, Comparator.naturalOrder())
        	);
        fillTable();
       
        current.setOnCloseRequest(event -> {
        	ClientUI.chat.accept(new Message(MessageType.logout, ClientController.client.globalUserID));
        	System.exit(0);
        });
        
    }

	private void fillTable() {
		tblReports.getItems().clear();
		for(WeeklyReport wk : reports) {
			WeeklyReportsTableRow row = new WeeklyReportsTableRow(wk.getTraineeID(),
					names.get(wk.getTraineeID()), wk.getYear(), wk.getMonth(), wk.getWeek(),
					wk.getStatus());
			tblReports.getItems().add(row);
		}
		
	}

	private void defineTable() {
		// Define table columns
	    TableColumn<WeeklyReportsTableRow, Integer> traineeIDColumn = new TableColumn<>("ID");
	    traineeIDColumn.setCellValueFactory(new PropertyValueFactory<>("traineeID"));

	    TableColumn<WeeklyReportsTableRow, String> nameColumn = new TableColumn<>("Name");
	    nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

	    TableColumn<WeeklyReportsTableRow, Integer> yearColumn = new TableColumn<>("Year");
	    yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));

	    TableColumn<WeeklyReportsTableRow, Integer> monthColumn = new TableColumn<>("Month");
	    monthColumn.setCellValueFactory(new PropertyValueFactory<>("month"));
	    
	    TableColumn<WeeklyReportsTableRow, Integer> weekColumn = new TableColumn<>("Week");
	    weekColumn.setCellValueFactory(new PropertyValueFactory<>("week"));
	    
	    TableColumn<WeeklyReportsTableRow, String> statusColumn = new TableColumn<>("Status");
	    statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

	    // Add the columns to the TableView
	    tblReports.getColumns().addAll(traineeIDColumn, nameColumn, yearColumn,
	    		monthColumn, weekColumn, statusColumn);

	    // Bind the data to the TableView
	    tblReports.setItems(data);
		
	}
	
	@FXML
    void clickCreate(MouseEvent event) throws IOException {
		start(event, "createTrainingPlan", "Create New Training Plan");
    }

    @FXML
    void clickTrainees(MouseEvent event) throws IOException {
    	start(event, "trainerTrainee", "My Trainees");
    }

}
