package client.gui.controllers;


import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.testfx.api.FxAssert;
import org.testfx.framework.junit5.ApplicationTest;

import client.gui.controllers.LoginController;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.stage.Stage;


public class LoginControllerTest extends ApplicationTest {

    @Override
    public void start(Stage primaryStage) {
        // Start the JavaFX application
        LoginController loginController = new LoginController();
        try {
            loginController.start(primaryStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void testLoginWithValidCredentials() {
        // Simulate valid email and password inputs
        clickOn("#txtEmail").write("manager");
        clickOn("#txtPassword").write("1");

        // Click on the Login button
        clickOn("#btnLogin");

        // Verify the appropriate message and window based on the user's role
        // Use TestFX assertions to validate UI components
        FxAssert.verifyThat("#lblError", label -> ((Labeled) label).getText().equals("132234543!manager"));
        // Verify the opened window based on the user's role
        // For example, if the user is a manager, assert that the managerRequestMain window is shown
    }

    @Test
    void testLoginWithEmptyFields() {
        // Leave the email and password fields empty
        // Click on the Login button

        // Verify the error message for empty fields
    	FxAssert.verifyThat("#lblError", label -> ((Labeled) label).getText().equals("please fill all fields"));
    }

    @Test
    void testLoginWithInvalidCredentials() {
        // Simulate invalid email and password inputs
        // Click on the Login button

        // Verify the error message for invalid credentials
        //FxAssert.verifyThat("#lblError", Label::getText, Matchers.equalTo("Invalid credentials"));
    }

    @Test
    void testForgotPassword() {
        // Click on the Forgot Password hyperlink

        // Verify the appropriate action, such as opening a new window or showing a popup
        // Use TestFX assertions to validate UI components
    }

    @Test
    void testSignUp() {
        // Click on the Sign Up hyperlink

        // Verify the appropriate action, such as opening a new window
        // Use TestFX assertions to validate UI components
    }
}